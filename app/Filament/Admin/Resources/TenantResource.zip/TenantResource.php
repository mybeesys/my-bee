<?php

namespace App\Filament\Admin\Resources;

use App\Filament\Admin\Resources;
use App\Models\Plan;
use App\Models\Subscription;
use App\Models\Tenant;
use Filament\Forms\Components\Fieldset;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Forms\Get;
use Filament\Forms\Set;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class TenantResource extends Resource
{
    protected static ?string $model = Tenant::class;

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

    protected static ?string $slug = "companies";

    protected static ?int $navigationSort = 2;

    public static function getModelLabel(): string
    {
        return __('fields.client');
    }

    public static function getNavigationLabel(): string
    {
        return __('fields.clients');
    }

    public static function getNavigationGroup(): ?string
    {
        return __('fields.clients');
    }

    public static function getNavigationBadge(): ?string
    {
        return static::getModel()::count();
    }

    public static function shouldRegisterNavigation(): bool
    {
        return false;
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make(__('fields.company_or_individual_details'))->schema([
                    Select::make('type')
                        ->label(__('fields.type'))
                        ->live()
                        ->required()
                        ->options(
                            [
                                'company' => str(__('fields.company'))->replace('ال', '')->value(),
                                'individual' => __('fields.individual')
                            ]),

                    TextInput::make('name')
                        ->label(__('fields.name'))
                        ->live(true)
                        ->afterStateUpdated(function ($state, Get $get, Set $set) {
                            if ($state and $get('type') === "individual") {
                                $names = explode(' ', $state);
                                $set('user_first_name', $names[0] ?? null);
                                $set('user_second_name', $names[1] ?? null);
                                $set('user_third_name', $names[2] ?? null);
                                $set('user_fourth_name', $names[3] ?? null);
                            }

                        })
                        ->required(),

                    TextInput::make('company_person')
                        ->label(__('fields.company_contact_person'))
                        ->visible(fn(Get $get) => $get('type') === 'company')
                        ->live(true)
                        ->afterStateUpdated(function ($state, Set $set) {
                            if ($state) {
                                $names = explode(' ', $state);
                                $set('user_first_name', $names[0] ?? null);
                                $set('user_second_name', $names[1] ?? null);
                                $set('user_third_name', $names[2] ?? null);
                                $set('user_fourth_name', $names[3] ?? null);
                            }

                        })
                        ->required(),

                    TextInput::make('trn')
                        ->label(__('fields.trn'))
                        ->visible(fn(Get $get) => $get('type') === 'company')
                        ->required(),

                    TextInput::make('phone')
                        ->label(__('fields.phone'))
                        ->unique(table: 'tenants', column: 'phone', ignorable: fn(?Model $record): ?Model => $record)
                        ->tel()
                        ->live(true)
                        ->afterStateUpdated(function ($state, Set $set) {
                            $set('user_phone', $state);
                        })
                        ->required(),

                    TextInput::make('mobile')
                        ->label(__('fields.mobile'))
                        ->unique(table: 'tenants', column: 'mobile', ignorable: fn(?Model $record): ?Model => $record)
                        ->tel()
                        ->required(),

                    TextInput::make('email')
                        ->label(__('fields.email'))
                        ->unique(table: 'tenants', column: 'email', ignorable: fn(?Model $record): ?Model => $record)
                        ->email()
                        ->live(true)
                        ->afterStateUpdated(function ($state, Set $set) {
                            $set('user_email', $state);
                        })
                        ->required(),

                    TextInput::make('address')
                        ->label(__('fields.address')),

                    Select::make('plan_id')
                        ->label(__('fields.subscription_plan'))
                        ->required()
                        ->options(Plan::active()->pluck('name', 'id')),

                ])->columns(4),

                Section::make(__('fields.account_and_login_details'))
                    ->visibleOn(Resources\TenantResource\Pages\CreateTenant::class)
                    ->schema([

                        TextInput::make('user_first_name')
                            ->label(__('fields.first_name'))
                            ->required(),

                        TextInput::make('user_second_name')
                            ->label(__('fields.second_name'))
                            ->required(),

                        TextInput::make('user_third_name')
                            ->label(__('fields.third_name')),

                        TextInput::make('user_fourth_name')
                            ->label(__('fields.fourth_name')),

                        TextInput::make('user_phone')
                            ->label(__('fields.phone'))
                            ->unique(table: 'users', column: 'phone', ignorable: fn(?Model $record): ?Model => $record)
                            ->required(),

                        TextInput::make('user_email')
                            ->label(__('fields.email'))
                            ->unique(table: 'users', column: 'email', ignorable: fn(?Model $record): ?Model => $record)
                            ->required(),

                        TextInput::make('user_password')
                            ->label(__('fields.password'))
                            ->password()
                            ->required(),

                        TextInput::make('user_password_confirmation')
                            ->label(__('fields.password_confirmation'))
                            ->password()
                            ->required()
                            ->same('user_password'),

                    ])->columns(4),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([

                Tables\Columns\TextColumn::make('name')
                    ->searchable()
                    ->label(__('fields.name'))
                    ->description(fn(Tenant $record) => __("fields.$record->type"))
                    ->toggleable(),

                Tables\Columns\TextColumn::make('phone')
                    ->searchable()
                    ->label(__('fields.phone'))
                    ->toggleable(),


                Tables\Columns\TextColumn::make('mobile')
                    ->searchable()
                    ->label(__('fields.mobile'))
                    ->toggleable(),


                Tables\Columns\TextColumn::make('email')
                    ->searchable()
                    ->label(__('fields.email'))
                    ->toggleable(),

                Tables\Columns\TextColumn::make('email')
                    ->searchable()
                    ->label(__('fields.email'))
                    ->toggleable(),

                Tables\Columns\TextColumn::make('subscription')
                    ->label(__('fields.subscription_plan'))
                    ->formatStateUsing(fn($record) => $record->subscription?->plan?->name)
                    ->toggleable(),

                Tables\Columns\IconColumn::make('active')
                    ->boolean()
                    ->label(__('fields.active')),

                Tables\Columns\TextColumn::make('created_at')
                    ->label(__('fields.join_date'))
                    ->dateTime('M j, Y')
                    ->sortable(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([

            ]);
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->with(['user', 'users']);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Resources\TenantResource\Pages\ListTenants::route('/'),
            'create' => Resources\TenantResource\Pages\CreateTenant::route('/create'),
            'edit' => Resources\TenantResource\Pages\EditTenant::route('/{record}/edit'),
        ];
    }
}
