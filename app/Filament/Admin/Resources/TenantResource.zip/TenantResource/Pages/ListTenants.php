<?php

namespace App\Filament\Admin\Resources\TenantResource\Pages;

use App\Filament\Admin\Resources\TenantResource;
use App\Models\Tenant;
use Filament\Actions;
use Filament\Resources\Components\Tab;
use Filament\Resources\Pages\ListRecords;
use Filament\Tables\Table;
use Illuminate\Contracts\Support\Htmlable;
use Illuminate\Contracts\View\View;
use Illuminate\Database\Eloquent\Builder;

class ListTenants extends ListRecords
{
    protected static string $resource = TenantResource::class;


    public function getHeading(): string|Htmlable
    {
        return __('fields.clients');
    }

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }

    public function getTabs(): array
    {
        return [
            Tenant::TYPE_COMPANY => Tab::make(__('fields.companies'))
                ->icon('heroicon-m-user-group')
                ->modifyQueryUsing(fn(Builder $query) => $query->where('type', Tenant::TYPE_COMPANY))
                ->badge(Tenant::query()->where('type', Tenant::TYPE_COMPANY)->count()),
            Tenant::TYPE_INDIVIDUAL => Tab::make(__('fields.individuals'))
                ->icon('heroicon-m-user')
                ->modifyQueryUsing(fn(Builder $query) => $query->where('type', Tenant::TYPE_INDIVIDUAL))
                ->badge(Tenant::query()->where('type', Tenant::TYPE_INDIVIDUAL)->count()),
        ];
    }
}
