<?php

    namespace App\Filament\Resources;

    use App\Filament\Resources\ProductResource\Pages;
    use App\Filament\Resources\ProductResource\RelationManagers;
    use App\Filament\Resources\ProductResource\Widgets\PricingOverview;
    use App\Models\Acc4;
    use App\Models\Category;
    use App\Models\ItemPrice;
    use App\Models\Product;
    use App\Models\ProductionCost;
    use App\Models\ProductProductionCost;
    use App\Models\ProductRawMaterial;
    use App\Models\ProductStock;
    use App\Models\RawMaterial;
    use App\Models\Unit;
    use App\Models\Warehouse;
    use Filament\Facades\Filament;
    use Filament\Forms;
    use Filament\Forms\Components\Repeater;
    use Filament\Forms\Components\Select;
    use Filament\Forms\Components\TextInput;
    use Filament\Notifications\Notification;
    use Filament\Pages\Page;
    use Filament\Resources\Form;
    use Filament\Resources\Resource;
    use Filament\Resources\Table;
    use Filament\Tables;
    use Illuminate\Database\Eloquent\Builder;
    use Illuminate\Support\Facades\DB;
    use Illuminate\Support\HtmlString;

    class ProductResource extends Resource
    {
        protected static ?string $model = Product::class;

        protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

        protected static ?int $navigationSort = 2;

        protected static ?string $slug = "warehouses/products";

        public static function getNavigationGroup(): ?string
        {
            return __('fields.warehouses');
        }

        public static function getLabel(): ?string
        {
            return __('fields.product');
        }

        public static function getPluralLabel(): ?string
        {
//            $p_c = module_enabled('production_costs');
//            return $p_c ? __("fields.products_and_raw_materials") : __('fields.products');
            return __('fields.products');
        }

        public static function shouldRegisterNavigation(): bool
        {
            return module_enabled('warehouses');
        }

        public static function getNavigationBadge(): ?string
        {
            return static::getModel()::count();
        }

        public static function form(Forms\Form $form): Forms\Form
        {
            return $form
                ->schema(static::getFormSchema(Forms\Components\Card::class))
                ->columns([
                    'sm' => 3,
                    'lg' => null,
                ]);
        }

        public static function getFormSchema(string $layout = Forms\Components\Grid::class): array
        {
            return [
                Forms\Components\Group::make()
                    ->schema([
                        $layout::make()
                            ->schema([

                                Forms\Components\TextInput::make('barcode')
                                    ->label(__('fields.barcode'))
                                    ->autofocus(),

                                Forms\Components\TextInput::make('name')
                                    ->required()
                                    ->label(__('fields.name')),

                                Select::make('category_id')
                                    ->label(__('fields.category'))
                                    ->options(Category::canListProduct()->pluck('name', 'id'))
                                    ->required()
                                    ->searchable(),


                                Select::make('small_unit_id')
                                    ->label(__('fields.small_unit'))
                                    ->options(Unit::pluck('name', 'id'))
                                    ->required()
                                    ->searchable(),

                                Select::make('medium_unit_id')
                                    ->label(__('fields.medium_unit'))
                                    ->options(Unit::pluck('name', 'id'))
                                    ->required()
                                    ->searchable(),

                                Select::make('large_unit_id')
                                    ->label(__('fields.large_unit'))
                                    ->options(Unit::pluck('name', 'id'))
                                    ->required()
                                    ->searchable(),

                                Forms\Components\TextInput::make('security_stock')
                                    ->required()
                                    ->default(10)
                                    ->label(__('fields.security_stock')),

                            ])->columns(3),

                        $layout::make()
                            ->disabled(fn(Page $livewire) => $livewire instanceof Pages\EditProduct)
                            ->visible(fn(Page $livewire) => $livewire instanceof Pages\CreateProduct)
                            ->schema([
                                Repeater::make('opening_stock')
                                    ->label(__('fields.opening_stock'))
                                    ->relationship('stocks')
                                    ->schema([

                                        Forms\Components\Hidden::make('type')
                                            ->default('opening-stock'),

                                        Forms\Components\Hidden::make('user_id')->default(function () {
                                            return auth()->user()->id;
                                        }),

                                        Forms\Components\Hidden::make('date')->default(function () {
                                            return now()->toDateString();
                                        }),
                                        Select::make('warehouse_id')
                                            ->label(__('fields.warehouse'))
                                            ->searchable()
                                            ->options(Warehouse::pluck('name', 'id'))
                                            ->required()
                                            ->columnSpan(1),
                                        Forms\Components\Hidden::make('qty_out')
                                            ->default(0),
                                        TextInput::make('qty_in')
                                            ->reactive()
                                            ->label(__('fields.qty'))
                                            ->numeric()
                                            ->afterStateUpdated(function (Forms\Set $set, Forms\Get $get, $state) {
                                                if ($state) {

                                                    $qty = $get('qty_in');
                                                    $unit_cost_sdg = $get('unit_cost_sdg');
                                                    $unit_cost_usd = $get('unit_cost_usd');

                                                    if ($qty and is_numeric($qty) and $qty > 0) {
                                                        if ($unit_cost_sdg and (is_numeric($unit_cost_sdg) or is_float($unit_cost_sdg)) and $unit_cost_sdg > 0) {
                                                            $set('total_sdg', number_format($qty * $unit_cost_sdg, 2, '.', ''));
                                                        }

                                                        if ($unit_cost_sdg and (is_numeric($unit_cost_sdg) or is_float($unit_cost_sdg)) and $unit_cost_sdg > 0) {
                                                            $set('total_usd', number_format($qty * $unit_cost_usd, 2, '.', ''));
                                                        }
                                                    }
                                                }

                                            })
                                            ->required(),
                                        TextInput::make('unit_cost_sdg')
                                            ->reactive()
                                            ->label(__('fields.unit_cost_sdg'))
                                            ->numeric()
                                            ->afterStateUpdated(function (Forms\Set $set, Forms\Get $get, $state) {

                                                if ($state and (is_numeric($state) or is_float($state)) and $state > 0) {

//                                                    dd($state, ex_rate());
                                                    //update total_sdg

                                                    $qty = $get('qty_in');
                                                    $unit_cost_sdg = $state;
                                                    $unit_cost_usd = $state / ex_rate();

                                                    if ($qty and is_numeric($qty) and $qty > 0) {
                                                        $set('total_sdg', number_format($qty * $unit_cost_sdg, 2, '.', ''));

                                                        $set('total_usd', number_format($qty * $unit_cost_usd, 2, '.', ''));
                                                    }


                                                    $set('unit_cost_usd', number_format($state / ex_rate(), 2, '.', ''));

                                                }

                                            })
                                            ->required(),
                                        TextInput::make('unit_cost_usd')
                                            ->reactive()
                                            ->label(__('fields.unit_cost_usd'))
                                            ->numeric()
                                            ->afterStateUpdated(function (Forms\Set $set, Forms\Get $get, $state) {

                                                if ($state and (is_numeric($state) or is_float($state)) and $state > 0) {

                                                    //update total_usd

                                                    $qty = $get('qty_in');
                                                    $unit_cost_usd = $state;
                                                    $unit_cost_sdg = $get('unit_cost_sdg');

                                                    if ($qty and is_numeric($qty) and $qty > 0) {
                                                        $set('total_usd', number_format($qty * $unit_cost_usd, 2, '.', ''));

                                                        $set('total_sdg', number_format(($state * ex_rate()) * $qty, 2, '.', ''));
                                                    }

                                                    if ($unit_cost_sdg != $state * ex_rate())
                                                        $set('unit_cost_sdg', number_format($state * ex_rate(), 2, '.', ''));

                                                }

                                            })
                                            ->required(),
                                        TextInput::make('total_sdg')
                                            ->reactive()
                                            ->disabled(true)
                                            ->dehydrated(false)
                                            ->label(__('fields.total_sdg')),
                                        TextInput::make('total_usd')
                                            ->disabled(true)
                                            ->dehydrated(false)
                                            ->label(__('fields.total_usd')),
                                    ])
                                    ->createItemButtonLabel(__('fields.add'))
                                    ->grid(1)
                                    ->collapsible()
                                    ->defaultItems(0)
                                    ->columns(7),
                            ])
                            ->columns(1),

                        $layout::make()
                            ->schema([
                                Forms\Components\FileUpload::make('images')
                                    ->label(__('fields.images'))
                                    ->image()
                                    ->enableReordering()
                                    ->enableOpen()
                                    ->enableDownload()
                                    ->multiple()
                                    ->maxSize(2048)
                                    ->directory('products'),
                            ])
                            ->columns(1),

                        $layout::make()
                            ->visible(fn(Page $livewire) => $livewire instanceof Pages\EditProduct)
                            ->schema([
                                Forms\Components\Placeholder::make('cost_per_item'),
                                Forms\Components\TextInput::make('raw_materials_per_item')
                                    ->dehydrated(false)
                                    ->disabled(true)
                                    ->afterStateHydrated(function (Forms\Set $set, $record) {
                                        if (!$record) return;
                                        $sub_total = 0;
                                        foreach ($record->rawMaterials as $item) {
                                            $sub_total += $item->qty * $item->price_per_unit;
                                        }

                                        $set('raw_materials_per_item', number_format($sub_total, 2));
                                    }),

                                Forms\Components\TextInput::make('pre_production_cost_per_item')
                                    ->dehydrated(false)
                                    ->disabled(true)
                                    ->afterStateHydrated(function (Forms\Set $set, $record) {
                                        if (!$record) return;

                                        $pre_cost = $record->costs->filter(function ($item) {
                                            return $item->type == "pre-production";
                                        })->sum('cost');

                                        $set('pre_production_cost_per_item', number_format($pre_cost, 2));

                                    }),
                                Forms\Components\TextInput::make('post_production_cost_per_item')
                                    ->dehydrated(false)
                                    ->disabled(true)
                                    ->afterStateHydrated(function (Forms\Set $set, $record) {
                                        if (!$record) return;

                                        $post_cost = $record->costs->filter(function ($item) {
                                            return $item->type == "post-production";
                                        })->sum('cost');

                                        $set('post_production_cost_per_item', number_format($post_cost, 2));
                                    }),

                                Forms\Components\TextInput::make('production_cost_per_item')
                                    ->dehydrated(false)
                                    ->disabled(true)
                                    ->afterStateHydrated(function (Forms\Set $set, $record) {
                                        if (!$record) return;

                                        $set('production_cost_per_item', number_format($record->costs->sum('cost'), 2));
                                    }),

                                Forms\Components\TextInput::make('total_cost_per_item')
                                    ->dehydrated(false)
                                    ->disabled(true)
                                    ->afterStateHydrated(function (Forms\Set $set, $record) {
                                        if (!$record) return;

                                        $sub_total = 0;
                                        foreach ($record->rawMaterials as $item) {
                                            $sub_total += $item->qty * $item->price_per_unit;
                                        }

                                        $set('total_cost_per_item', number_format($record->costs->sum('cost') + $sub_total, 2));
                                    }),

                            ]),

                    ])->columnSpan([
                        'sm' => 3,
                    ]),
            ];
        }

        public static function table(Tables\Table $table): Tables\Table
        {
            return $table
                ->columns([
                    Tables\Columns\ImageColumn::make('image')
                        ->label(__('fields.image'))
                        ->toggleable()
                        ->toggledHiddenByDefault()
                        ->getStateUsing(function ($record) {
                            return \Storage::disk('public')->url($record->images[0] ?? "");
                        }),
                    Tables\Columns\TextColumn::make('name')
                        ->label(__('fields.name'))
                        ->searchable(),

                    Tables\Columns\TextColumn::make('category.name')
                        ->searchable()
                        ->label(__('fields.category')),

                    Tables\Columns\TextColumn::make('barcode')
                        ->label(__('fields.barcode'))
                        ->toggleable()
                        ->toggledHiddenByDefault()
                        ->searchable(),
                    Tables\Columns\TextColumn::make('stock')
                        ->label(__('fields.stock'))
                        ->getStateUsing(function ($record) {
                            return $record->stocks->sum(function ($i){
                                return $i->available;
                            });
                        }),

                    Tables\Columns\TextColumn::make('price_sdg')
                        ->label(__('fields.price_sdg'))
                        ->getStateUsing(function ($record) {
                            $lastPrice = $record->acc4->lastPrice;
                            return $lastPrice == null ? "-" : number_format($lastPrice->sdg_price, 2) . ' SDG';
                        }),

                    Tables\Columns\TextColumn::make('price_usd')
                        ->label(__('fields.price_usd'))
                        ->getStateUsing(function ($record) {
                            $lastPrice = $record->acc4->lastPrice;
                            return $lastPrice == null ? "-" : number_format($lastPrice->usd_price, 2) . ' USD';
                        }),

                    Tables\Columns\TextColumn::make('raw_materials_sub_total')
                        ->label(__('fields.raw_materials_sub_total'))
                        ->toggleable()
                        ->toggledHiddenByDefault()
                        ->getStateUsing(function ($record) {
                            $sub_total = 0;
                            foreach ($record->rawMaterials as $item) {
                                $sub_total += $item->qty * $item->price_per_unit;
                            }
                            return number_format($sub_total, 2);
                        }),

                    Tables\Columns\TextColumn::make('production_pre_cost_total')
                        ->label(__('fields.production_pre_cost_total'))
                        ->toggleable()
                        ->toggledHiddenByDefault()
                        ->getStateUsing(function ($record) {
                            $cost = $record->costs->filter(function ($item) {
                                return $item->type == "pre-production";
                            })->sum('cost');
                            return number_format($cost, 2);
                        }),

                    Tables\Columns\TextColumn::make('production_post_cost_total')
                        ->label(__('fields.post_production_cost'))
                        ->toggleable()
                        ->toggledHiddenByDefault()
                        ->getStateUsing(function ($record) {
                            $cost = $record->costs->filter(function ($item) {
                                return $item->type == "post-production";
                            })->sum('cost');

                            return number_format($cost, 2);

                        }),

                    Tables\Columns\TextColumn::make('production_costs_sub_total')
                        ->label(__('fields.production_costs_sub_total'))
                        ->toggleable()
                        ->toggledHiddenByDefault()
                        ->getStateUsing(function ($record) {
                            return number_format($record->costs->sum('cost'), 2);
                        }),


                    Tables\Columns\TextColumn::make('production_total_cost')
                        ->label(__('fields.production_total_cost'))
                        ->toggleable()
                        ->toggledHiddenByDefault()
                        ->getStateUsing(function ($record) {
                            $rawMaterialsCost = 0;
                            foreach ($record->rawMaterials as $item) {
                                $rawMaterialsCost += $item->qty * $item->price_per_unit;
                            }

                            return number_format($record->costs->sum('cost') + $rawMaterialsCost, 2);
                        }),

                    Tables\Columns\TextColumn::make('description')
                        ->label(__('fields.description'))
                        ->getStateUsing(function ($record) {
                            return new HtmlString($record->description);
                        }),
                    Tables\Columns\TextColumn::make('created_at')
                        ->toggleable()
                        ->label(__('fields.created_at'))
                        ->dateTime('M j, Y')
                        ->sortable(),
                ])
                ->filters([
                    Tables\Filters\Filter::make('created_at')
                        ->label(__('fields.created_at'))
                        ->form([
                            Forms\Components\DatePicker::make('created_from')
                                ->label(__('fields.created_from')),
                            Forms\Components\DatePicker::make('created_until')
                                ->label(__('fields.created_until')),
                        ])
                        ->query(function ($query, array $data) {
                            return $query
                                ->when($data['created_from'],
                                    fn($query) => $query->whereDate('created_at', '>=', $data['created_from']))
                                ->when($data['created_until'],
                                    fn($query) => $query->whereDate('created_at', '<=', $data['created_until']));
                        })
                ])
                ->actions([
                    Tables\Actions\ActionGroup::make([
                        Tables\Actions\Action::make('add_raw_material')
                            ->label(__('fields.add_raw_material'))
                            ->modalWidth('lg')
                            ->form([
                                Forms\Components\Select::make('raw_material')
                                    ->label(__('fields.raw_material'))
                                    ->required()
                                    ->options(function ($record) {
                                        return RawMaterial::pluck('name', 'id')->except($record->rawMaterials->pluck('raw_material_id')->toArray());
                                    }),
                                Forms\Components\TextInput::make('price_per_unit')
                                    ->label(__('fields.unit_cost_sdg'))
                                    ->required()
                                    ->minValue(1)
                                    ->numeric(),
                                Forms\Components\TextInput::make('qty')
                                    ->label(__('fields.qty'))
                                    ->required()
                                    ->minValue(1)
                                    ->maxValue(100000),
                                Forms\Components\RichEditor::make('description')
                                    ->label(__('fields.description')),
                            ])
                            ->icon('heroicon-o-pencil')
                            ->action(function (Product $record, array $data) {

                                ProductRawMaterial::create(
                                    [
                                        'product_id' => $record->id,
                                        'raw_material_id' => $data['raw_material'],
                                        'qty' => $data['qty'],
                                        'price_per_unit' => $data['price_per_unit'],
                                        'description' => $data['description'] ?? null,
                                    ]
                                );
                                Notification::make()
                                    ->title("Saved")
                                    ->success()
                                    ->send();
                            })
                            ->requiresConfirmation()
                            ->color('success'),

                        Tables\Actions\Action::make('add_production_cost')
                            ->label(__('fields.add_production_cost'))
                            ->modalWidth('lg')
                            ->form([
                                Forms\Components\Radio::make('type')
                                    ->label(__('fields.type'))
                                    ->required()
                                    ->options(function () {
                                        return [
                                            'pre-production' => 'pre-production',
                                            'post-production' => 'post-production'
                                        ];
                                    }),

                                Forms\Components\Select::make('production_cost')
                                    ->label(__('fields.production_cost'))
                                    ->required()
                                    ->options(function ($record) {
                                        return ProductionCost::pluck('name', 'id');
                                    }),
                                Forms\Components\TextInput::make('cost')
                                    ->label(__('fields.amount'))
                                    ->required()
                                    ->minValue(1)
                                    ->numeric(),
                                Forms\Components\RichEditor::make('description')
                                    ->label(__('fields.description')),
                            ])
                            ->icon('heroicon-o-pencil')
                            ->action(function (Product $record, array $data) {

                                ProductProductionCost::create(
                                    [
                                        'product_id' => $record->id,
                                        'type' => $data['type'],
                                        'production_cost_id' => $data['production_cost'],
                                        'cost' => $data['cost'],
                                        'description' => $data['description'] ?? null,
                                    ]
                                );

                                Notification::make()
                                    ->title("تم إضافة التكاليف")
                                    ->success()
                                    ->send();
                            })
                            ->requiresConfirmation()
                            ->color('success'),

                        Tables\Actions\Action::make('add_price')
                            ->label(__('fields.add_pricing'))
                            ->modalWidth('lg')
                            ->form([
                                Forms\Components\TextInput::make('item')
                                    ->label(__('fields.product'))
                                    ->disabled(1)
                                    ->afterStateHydrated(function (Forms\Components\TextInput $component, $record) {
                                        $component->state($record->name);
                                    }),

                                Forms\Components\TextInput::make('last_pricing_date')
                                    ->dehydrated(false)
                                    ->label(__('fields.last_pricing_date'))
                                    ->disabled(1)
                                    ->afterStateHydrated(function (Forms\Components\TextInput $component, $record) {
                                        $lastPrice = $record->acc4->lastPrice;
                                        $state = $lastPrice == null ? "-" : $lastPrice->date->format('d-m-Y');
                                        $component->state($state);
                                    }),

                                Forms\Components\TextInput::make('last_pricing_sdg')
                                    ->dehydrated(false)
                                    ->label(__('fields.last_pricing_sdg'))
                                    ->disabled(1)
                                    ->afterStateHydrated(function (Forms\Components\TextInput $component, $record) {
                                        $lastPrice = $record->acc4->lastPrice;
                                        $state = $lastPrice == null ? "-" : number_format($lastPrice->sdg_price, 2) . ' SDG';
                                        $component->state($state);
                                    }),

                                Forms\Components\TextInput::make('last_pricing_usd')
                                    ->dehydrated(false)
                                    ->label(__('fields.last_pricing_usd'))
                                    ->disabled(1)
                                    ->afterStateHydrated(function (Forms\Components\TextInput $component, $record) {
                                        $lastPrice = $record->acc4->lastPrice;
                                        $state = $lastPrice == null ? "-" : number_format($lastPrice->usd_price, 2) . ' USD';
                                        $component->state($state);
                                    }),


                                Forms\Components\TextInput::make('exchange_rate')
                                    ->label(__('fields.exchange_rate'))
                                    ->required()
                                    ->minValue(1)
                                    ->maxValue(99000000)
                                    ->afterStateHydrated(function (Forms\Components\TextInput $component, $record) {
                                        $component->state(ex_rate());
                                    }),

                                Forms\Components\TextInput::make('sdg_price')
                                    ->reactive()
                                    ->label(__('fields.price_sdg'))
                                    ->required()
                                    ->numeric()
                                    ->minValue(1)
                                    ->maxValue(99000000)
                                    ->afterStateUpdated(function (Forms\Components\TextInput $component, $state, Forms\Get $get, Forms\Set $set) {
                                        $ex_rate = $get('exchange_rate');

                                        if ($state and $ex_rate and $state > 0 and $ex_rate > 0 and (is_numeric($state) or is_float($state))
                                            and (is_numeric($ex_rate) or is_float($ex_rate))) {
                                            $set('usd_price', number_format($state / $ex_rate, 2, '.', ''));
                                        }
                                    }),

                                Forms\Components\TextInput::make('usd_price')
                                    ->reactive()
                                    ->label(__('fields.price_usd'))
                                    ->required()
                                    ->numeric()
                                    ->maxValue(99000000)
                                    ->afterStateUpdated(function (Forms\Components\TextInput $component, $state, Forms\Get $get, Forms\Set $set) {
                                        $ex_rate = $get('exchange_rate');

                                        if ($state and $ex_rate and $state > 0 and $ex_rate > 0 and (is_numeric($state) or is_float($state))
                                            and (is_numeric($ex_rate) or is_float($ex_rate))) {
                                            $set('sdg_price', number_format($state * $ex_rate, 2, '.', ''));
                                        }
                                    }),
                            ])
                            ->icon('heroicon-o-pencil')
                            ->action(function (Product $record, array $data) {
                                ItemPrice::create(
                                    [
                                        'acc4_code' => $record->acc4->code,
                                        'sdg_price' => $data['sdg_price'],
                                        'usd_price' => $data['usd_price'],
                                        'exchange_rate' => $data['exchange_rate'],
                                        'date' => now(),
                                    ]
                                );

                                Notification::make()
                                    ->title(__('fields.added_pricing_alert'))
                                    ->success()
                                    ->send();
                            })
                            ->requiresConfirmation()
                            ->color('success'),

                        Tables\Actions\DeleteAction::make()
                            ->action(function (Product $record) {
                                if(can_delete_product($record))
                                {
                                    try {
                                        DB::beginTransaction();

                                        $deleted = Acc4::where('code', $record->acc4->code)->first()->delete();

                                        if(!$deleted)
                                            throw new \Exception('Unable to delete account.');

                                        $record->delete();

                                        DB::commit();

                                        Notification::make()
                                            ->title(__('fields.record_deleted_alert'))
                                            ->success()
                                            ->send();

                                    }catch (\Exception $exception)
                                    {
                                        DB::rollBack();
                                    }
                                }else{
                                    Notification::make()
                                        ->title(__('fields.record_in_use_alert'))
                                        ->warning()
                                        ->send();
                                }
                            }),
                    ]),
                ])
                ->bulkActions([
                ])->deferLoading();
        }

        public static function getRelations(): array
        {
            return [
                RelationManagers\StocksRelationManager::class,
                RelationManagers\RawMaterialsRelationManager::class,
                RelationManagers\CostsRelationManager::class,
            ];
        }

        public static function getWidgets(): array
        {
            return [
                PricingOverview::class,
            ];
        }

        public static function getEloquentQuery(): Builder
        {
            return parent::getEloquentQuery()->with(['category', 'acc4.lastPrice', 'costs.ProductionCost', 'rawMaterials', 'stocks.warehouse'])->latest();
        }

        public static function getPages(): array
        {
            return [
                'index' => Pages\ListProducts::route('/'),
                'create' => Pages\CreateProduct::route('/create'),
                'edit' => Pages\EditProduct::route('/{record}/edit'),
            ];
        }

    }
