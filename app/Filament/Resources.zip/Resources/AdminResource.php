<?php

namespace App\Filament\Resources;

use App\Filament\Resources\AdminResource\Pages;
use App\Filament\Resources\AdminResource\RelationManagers;
use App\Models\Admin;
use App\Models\User;
use App\Rules\PasswordStrengthRule;
use Filament\Facades\Filament;
use Filament\Forms;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Resources\Form;
use Filament\Resources\Resource;
use Filament\Resources\Table;
use Filament\Tables;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Spatie\Permission\Models\Role;

class AdminResource extends Resource
{

    protected static ?string $model = User::class;

    protected static ?string $navigationIcon = 'heroicon-o-users';

    protected static ?string $recordTitleAttribute = "phone";

    protected static ?string $slug = "administrative/admins";


    public static function getNavigationGroup(): ?string
    {
        return __('fields.roles_permissions');
    }

    public static function getLabel(): ?string
    {
        return __('fields.admin');    }

    public static function getPluralLabel(): ?string
    {
        return __('fields.administrators');
    }

    public static function getRecordTitle(?Model $record): ?string
    {
        return $record->full_name;
    }

    public static function getNavigationBadge(): ?string
    {
        return static::getModel()::with(['roles'])->whereHas('roles', function ($q) {
            return $q->whereIn('name', [
                User::ROLE_SUPER_VISOR,
                User::ROLE_SUPER_ADMIN,
            ]);
        })->count();
    }

    public static function form(Forms\Form $form): Forms\Form
    {
        return $form
            ->schema(static::getFormSchema(Forms\Components\Card::class))
            ->columns([
                'sm' => 3,
                'lg' => null,
            ]);
    }

    public static function getFormSchema(string $layout = Forms\Components\Grid::class): array
    {
        return [
            Forms\Components\Group::make()
                ->schema([
                    $layout::make()
                        ->schema([
                            Forms\Components\TextInput::make('first_name')
                                ->label(__('fields.first_name'))
                                ->autofocus()
                                ->required(),
                            Forms\Components\TextInput::make('second_name')
                                ->label(__('fields.second_name'))
                                ->required(),
                            Forms\Components\TextInput::make('third_name')
                                ->label(__('fields.third_name')),
                            Forms\Components\TextInput::make('fourth_name')
                                ->label(__('fields.fourth_name')),

                            Forms\Components\TextInput::make('phone')
                                ->label(__('fields.phone'))
                                ->unique(ignorable: fn(?Model $record): ?Model => $record)
                                ->required()
                                ->type('tel'),
//                                    ->rules(['required', 'phone:SD', 'unique:users,phone']),
                            Forms\Components\TextInput::make('email')
                                ->label(__('fields.email'))
                                ->disabled(fn($context) => $context == "edit")
                                ->unique(ignorable: fn(?Model $record): ?Model => $record)
                                ->required()
                                ->type('email'),
                            Forms\Components\TextInput::make('address')
                                ->label(__('fields.address')),
                            Forms\Components\Select::make('gender')
                                ->label(__('fields.gender'))
                                ->options([
                                    'male' => 'Male',
                                    'female' => 'Female',
                                ])
                                ->required(),

                            Forms\Components\DatePicker::make('dob')
                                ->label(__('fields.dob'))
                                ->seconds(false)
                                ->minDate(now()->subYears(60))
                                ->maxDate(now()->subYears(15))
                                ->default(now()->subYear(32))
                                ->displayFormat('d/m/Y'),
                        ])->columns([
                            'sm' => 2,
                        ]),

                    $layout::make()
                        ->visible(fn(Page $livewire) => $livewire instanceof Pages\CreateAdmin)
                        ->schema([

                            Forms\Components\TextInput::make('password')
                                ->label(__('fields.password'))
                                ->required()
                                ->reactive()
                                ->password()
                                ->rules(['required', new PasswordStrengthRule(8)]),

                            Forms\Components\TextInput::make('password_confirmation')
                                ->label(__('fields.password_confirmation'))
                                ->required()
                                ->password()
                                ->same('password')
                                ->visible(fn(Forms\Get $get) => $get('password') !== null || $get('password') != "")
                        ])
                        ->columns(1),
                    $layout::make()
                        ->visible(fn(Page $livewire) => $livewire instanceof Pages\EditAdmin)
                        ->schema([

                            Forms\Components\Checkbox::make('change_password')
                                ->label(__('fields.change_password'))
                                ->reactive()
                                ->inLine(),
                            Forms\Components\TextInput::make('password')
                                ->label(__('fields.password'))
                                ->reactive()
                                ->password()
                                ->rules(['required', new PasswordStrengthRule(8)])
                                ->visible(fn(Forms\Get $get) => $get('change_password') === true),

                            Forms\Components\TextInput::make('password_confirmation')
                                ->label(__('fields.password_confirmation'))
                                ->required()
                                ->password()
                                ->same('password')
                                ->visible(fn(Forms\Get $get) => $get('password') !== null && $get('change_password') === true)
                        ])
                        ->columns(1),
                ])->columnSpan([
                    'sm' => 2,
                ]),

            Forms\Components\Group::make()
                ->visible(fn($context) => $context == "edit")
                ->schema([
                    Forms\Components\Section::make('Status')
                        ->schema([
                            Forms\Components\Toggle::make('active')
                                ->label(__('fields.active'))
                                ->dehydrated(false)
                                ->disabled(1),
                            Forms\Components\Toggle::make('email_verified_at')
                                ->label(__('fields.email_verified'))
                                ->dehydrated(false)
                                ->hint(function ($record) {
                                    if ($record)
                                        return $record->email_verified_at ? $record->email_verified_at->diffForHumans() : null;
                                })
                                ->disabled(1),
                            Forms\Components\Toggle::make('phone_verified_at')
                                ->label(__('fields.phone_verified'))
                                ->dehydrated(false)
                                ->hint(function ($record) {
                                    if ($record)
                                        return $record->phone_verified_at ? $record->phone_verified_at->diffForHumans() : null;
                                })
                                ->disabled(1),
                        ]),

                    Forms\Components\Section::make('Roles')
                        ->schema([
                            Forms\Components\TextInput::make('roles_list')
                                ->label(__('fields.roles_list'))
                                ->disabled(1)
                                ->dehydrated(0),
                        ]),
                ])
                ->columnSpan(['lg' => 1]),
        ];
    }

    public static function table(Tables\Table $table): Tables\Table
    {

        return $table
            ->columns([
                Tables\Columns\TextColumn::make('uuid')
                    ->label(__('fields.uuid'))
                    ->toggleable()
                    ->toggledHiddenByDefault()
                    ->searchable(),

                Tables\Columns\TextColumn::make('first_name')
                    ->label(__('fields.first_name'))
                    ->searchable()
                    ->toggleable()
                    ->description(function ($record) {
                        return "Role: " . implode(',', $record->roles->pluck('name')->toArray());
                    })
                    ->getStateUsing(function ($record) {
                        return ucwords($record->full_name);
                    }),
                Tables\Columns\TextColumn::make('email')
                    ->label(__('fields.email'))
                    ->toggleable()
                    ->toggledHiddenByDefault()
                    ->sortable()
                    ->searchable(),
                Tables\Columns\TextColumn::make('phone')
                    ->label(__('fields.phone'))
                    ->toggleable()
                    ->sortable()
                    ->searchable(),
                Tables\Columns\TextColumn::make('gender')
                    ->label(__('fields.gender'))
                    ->toggleable()
                    ->toggledHiddenByDefault(),
                Tables\Columns\TextColumn::make('address')
                    ->label(__('fields.address'))
                    ->toggleable()
                    ->toggledHiddenByDefault()
                    ->sortable()
                    ->searchable(),

                Tables\Columns\TextColumn::make('age')
                    ->label(__('fields.age'))
                    ->toggleable()
                    ->toggledHiddenByDefault()
                    ->getStateUsing(function ($record) {
                        if ($record->dob) {
                            return $record->dob->age;
                        }
                        return "N/A";
                    }),

                Tables\Columns\TextColumn::make('dob')
                    ->label(__('fields.dob'))
                    ->toggleable()
                    ->toggledHiddenByDefault()
                    ->sortable()
                    ->searchable(),

                Tables\Columns\TextColumn::make('email_verified_at')
                    ->label(__('fields.email_verified_at'))
                    ->toggleable()
                    ->toggledHiddenByDefault()
                    ->dateTime('M j, Y'),
                Tables\Columns\TextColumn::make('phone_verified_at')
                    ->label(__('fields.phone_verified_at'))
                    ->toggleable()
                    ->toggledHiddenByDefault()
                    ->dateTime('M j, Y'),
                Tables\Columns\BooleanColumn::make('active')
                    ->label(__('fields.active'))
                    ->toggleable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('created_at')
                    ->label(__('fields.created_at'))
                    ->toggleable()
                    ->toggledHiddenByDefault()
                    ->dateTime('M j, Y')
                    ->sortable(),
                Tables\Columns\TextColumn::make('updated_at')
                    ->label(__('fields.updated_at'))
                    ->toggleable()
                    ->toggledHiddenByDefault()
                    ->dateTime('M j, Y')
                    ->sortable(),
            ])->filters([

                Tables\Filters\SelectFilter::make('gender')
                    ->label(__('fields.gender'))
                    ->options([
                        'male' => 'Male',
                        'female' => 'Female',
                    ]),
            ])->actions([
                Tables\Actions\ActionGroup::make([

                    Tables\Actions\Action::make('reset_password')
                        ->label(__('fields.reset_password'))
                        ->form([
                            Forms\Components\TextInput::make('password')
                                ->label(__('fields.new_password'))
                                ->password()
                                ->minLength(8)
                                ->required(),
                        ])
                        ->modalHeading(function ($record) {
                            return $record->full_name;
                        })
                        ->modalSubheading('Are you sure you\'d like to reset the admin\'s password?')
                        ->modalButton('Yes, reset account')
                        ->icon('heroicon-o-lock-open')
                        ->action(function (User $record, array $data) {
                            try {
                                abort_if(!auth()->user()->isSuperAdmin(), 403, 'Only a super admin can perform this action');
                                $record->update(['password' => bcrypt($data['password'])]);
                                Notification::make()
                                    ->title("New password saved")
                                    ->success()
                                    ->send();
                            } catch (\Exception $exception) {
                                Notification::make()
                                    ->title($exception->getMessage())
                                    ->danger()
                                    ->persistent()
                                    ->send();
                            }
                        })
                        ->requiresConfirmation()
                        ->color('danger'),

                    Tables\Actions\Action::make('mark_active_inactive')
                        ->label(function (User $record) {
                            return $record->active ? __('fields.deactivate') : __('fields.activate');
                        })
                        ->color('danger')
                        ->icon('heroicon-o-pencil')
                        ->action(function (User $record) {
                            if (auth()->id() == $record->id || $record->isSuperAdmin()) {
                                Notification::make()
                                    ->title("Operation not allowed")
                                    ->danger()
                                    ->send();
                                return;
                            }
                            $record->update(['active' => !$record->active]);
                            $record->refresh();
                            Filament::notify('success', "Account status updated");

                        })
                        ->requiresConfirmation()
                        ->color('warning'),
                ]),
            ])->deferLoading();
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->with(['roles', 'media'])->whereHas('roles', function ($q) {
            return $q->whereIn('name', [
                User::ROLE_SUPER_VISOR,
                User::ROLE_SUPER_ADMIN
            ]);
        })->latest();
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListAdmins::route('/'),
            'create' => Pages\CreateAdmin::route('/create'),
            'edit' => Pages\EditAdmin::route('/{record}/edit'),
        ];
    }

    public static function canDelete(Model $record): bool
    {
        return false;
    }
}
