<?php

    namespace App\Filament\Resources;

    use App\Filament\Resources\ClientReportResource\Pages;
    use App\Filament\Resources\ClientReportResource\RelationManagers;
    use App\Models\Client;
    use App\Models\ClientReport;
    use Filament\Facades\Filament;
    use Filament\Forms;
    use Filament\Notifications\Notification;
    use Filament\Resources\Resource;
    use Filament\Tables;
    use Illuminate\Database\Eloquent\Builder;
    use Filament\Forms\Form;
    use Filament\Tables\Table;

    class ClientReportResource extends Resource
    {
        protected static ?string $model = ClientReport::class;

        protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

        protected static ?string $slug = "crm/reports";

        protected static ?int $navigationSort = 2;

        public static function getNavigationGroup(): ?string
        {
            return __('fields.crm');
        }

        public static function getLabel(): ?string
        {
            return __('fields.report');
        }

        public static function getPluralLabel(): ?string
        {
            return __('fields.reports');
        }

        public static function shouldRegisterNavigation(): bool
        {
            return module_enabled('crm');
        }

        public static function getNavigationBadge(): ?string
        {
            return ClientReport::where('status', 'pending')->count();
        }

        public static function form(Form $form): Form
        {
            return $form
                ->schema(static::getFormSchema(Forms\Components\Card::class))
                ->columns([
                    'sm' => 3,
                    'lg' => null,
                ]);
        }

        public static function getFormSchema(string $layout = Forms\Components\Grid::class): array
        {
            return [
                Forms\Components\Group::make()
                    ->schema([
                        $layout::make()
                            ->schema([
                                Forms\Components\Hidden::make('user_id')
                                    ->afterStateHydrated(function (Forms\Components\Hidden $component, $state) {
                                        $component->state(auth()->id());
                                    }),
                                Forms\Components\Select::make('client_id')
                                    ->searchable()
                                    ->label(__('fields.client'))
                                    ->options(Client::pluck('name', 'id'))
                                    ->required(),
                                Forms\Components\TextInput::make('subject')
                                    ->label(__('fields.subject'))
                                    ->required(),

                            ])->columns(2),

                        $layout::make()
                            ->schema([
                                Forms\Components\MarkdownEditor::make('report')->label(__('fields.report'))->required(),
                            ]),

                        $layout::make()
                            ->schema([
                                Forms\Components\MarkdownEditor::make('notes')->label(__('fields.notes')),
                            ]),

                        $layout::make()
                            ->schema([
                                Forms\Components\FileUpload::make('files')
                                    ->label(__('fields.files'))
                                    ->image()
                                    ->enableReordering()
                                    ->enableOpen()
                                    ->enableDownload()
                                    ->multiple()
                                    ->maxSize(2048)
                                    ->directory('clients/reports'),
                            ])
                            ->columns(1),
                    ])->columnSpan([
                        'sm' => 3,
                    ]),
            ];
        }

        public static function table(Table $table): Table
        {
            return $table
                ->columns([
                    Tables\Columns\TextColumn::make('client.name')
                        ->sortable(true)
                        ->searchable()
                        ->label(__('fields.name')),
                    Tables\Columns\BadgeColumn::make('status')
                        ->getStateUsing(function ($record) {
                            return __('fields.' . $record->status);
                        })
                        ->colors([
                            'success' => __('fields.processed'),
                            'danger' => __('fields.pending'),
                            'warning' => __('fields.processing'),
                        ])
                        ->sortable(true)
                        ->searchable()
                        ->label(__('fields.status')),

                    Tables\Columns\TextColumn::make('user.name')
                        ->searchable()
                        ->label(__('fields.created_by')),

                    Tables\Columns\TextColumn::make('processedBy.name')
                        ->searchable()
                        ->label(__('fields.processed_by')),

                ])
                ->filters([
                    Tables\Filters\SelectFilter::make('status')
                        ->label(__('fields.status'))
                        ->options([
                            'pending' => __('fields.pending'),
                            'processing' => __('fields.processing'),
                            'processed' => __('fields.processed'),
                        ]),

                    Tables\Filters\SelectFilter::make('client')
                        ->label(__('fields.clients'))
                        ->relationship('client', 'name'),
                ])
                ->actions([
                    Tables\Actions\ActionGroup::make([
                        Tables\Actions\EditAction::make(),
                        Tables\Actions\DeleteAction::make(),
                        Tables\Actions\Action::make('changeState')
                            ->visible(function ($record){
                                return $record->status != "processed";
                            })
                            ->label(__('fields.change_state'))
                            ->icon('heroicon-o-pencil')
                            ->form([
                                Forms\Components\Select::make('status')
                                    ->afterStateHydrated(function (Forms\Components\Select $component, $record) {
                                        $component->state($record->status);
                                    })
                                    ->label(__('fields.status'))
                                    ->required()
                                    ->options(function (){
                                        return [
                                            'pending' => 'Pending',
                                            'processing' => 'Processing',
                                            'processed' => 'Processed',
                                        ];
                                    }),
                            ])
                            ->action(function (ClientReport $record, array $data) {
                                $record->update(['status' => $data['status']]);

                                Notification::make()
                                    ->title(__('fields.status_updated'))
                                    ->success()
                                    ->send();
                            })
                            ->requiresConfirmation()
                            ->color('warning'),
                    ])
                ])
                ->bulkActions([
//                    FilamentExport::make('export'),
//                    Tables\Actions\DeleteBulkAction::make(),
                ])->deferLoading();
        }

        public static function getEloquentQuery(): Builder
        {
            return parent::getEloquentQuery()->with(['client', 'user', 'processedBy'])->latest();
        }

        public static function getRelations(): array
        {
            return [
                //
            ];
        }

        public static function getPages(): array
        {
            return [
                'index' => Pages\ListClientReports::route('/'),
                'create' => Pages\CreateClientReport::route('/create'),
                'edit' => Pages\EditClientReport::route('/{record}/edit'),
            ];
        }
    }
