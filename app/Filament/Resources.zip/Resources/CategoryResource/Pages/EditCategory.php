<?php

    namespace App\Filament\Resources\CategoryResource\Pages;

    use App\Filament\Resources\CategoryResource;
    use App\Models\Category;
    use App\Services\CategoryService;
    use Filament\Facades\Filament;
    use Filament\Resources\Pages\EditRecord;
    use Illuminate\Database\Eloquent\Model;
    use Illuminate\Support\Facades\Cache;
    use Illuminate\Support\Facades\Storage;

    class EditCategory extends EditRecord
    {
        use EditRecord\Concerns\Translatable;

        protected static string $resource = CategoryResource::class;


        public function delete(): void
        {
            abort_unless(static::getResource()::canDelete($this->record), 403);

            $this->callHook('beforeDelete');

            if ($this->record->children->isNotEmpty()) {
                $this->notify('warning', trans('alert.record_in_use'));
                return;
            }

            $this->record->delete();

            $this->callHook('afterDelete');

            if (filled($this->getDeletedNotificationMessage())) {
                $this->notify(
                    'success',
                    $this->getDeletedNotificationMessage(),
                );
            }


            $this->redirect($this->getDeleteRedirectUrl());

        }

        protected function afterFill()
        {
        }

        protected function afterSave()
        {

            $this->record->load('children', 'allChildren', 'parent');

            $service = new CategoryService();

            if($this->record->parent)
            {
//            $data = $service->subOf($this->record->parent->slug);
//            $data = $data->add($this->record)->sortBy('order');
//            Cache::put("sub-of-".$this->record->parent->slug, $data);//            Cache::put("sub-of-".$this->record->parent->slug, $data);
                Cache::clear("sub-of-".$this->record->parent->slug);
            }else{ //main
                $service->clearMainCategories();
            }
        }

        protected function afterDelete()
        {
            $this->record->load('children', 'allChildren', 'parent');

            $service = new CategoryService();

            if($this->record->parent)
            {
                Cache::clear("sub-of-".$this->record->parent->slug);
//                Filament::notify('info', "Cache of ({$this->record->parent->name}) cleared.");
            }else{ //main
                $service->clearMainCategories();
            }
        }
    }
