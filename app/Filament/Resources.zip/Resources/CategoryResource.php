<?php

    namespace App\Filament\Resources;

    use App\Filament\Resources\CustomerResource\Widgets\CustomerOverview;
    use App\Services\MediaService;
    use Filament\Facades\Filament;
    use Filament\Forms\Components\Select;
    use Filament\Forms\Components\TextInput;
    use App\Filament\Resources\CategoryResource\Pages;
    use App\Filament\Resources\CategoryResource\RelationManagers;
    use App\Models\Category;
    use Filament\Forms;
    use Filament\Notifications\Notification;
    use Filament\Resources\Concerns\Translatable;
    use Filament\Forms\Form;
    use Filament\Resources\Resource;
    use Filament\Tables;
    use Illuminate\Database\Eloquent\Builder;
    use Illuminate\Database\Eloquent\Model;
    use Illuminate\Support\Facades\Cache;
    use Illuminate\Support\Facades\Storage;

    class CategoryResource extends Resource
    {
        use Translatable;


        protected static ?string $model = Category::class;

        protected static ?string $recordTitleAttribute = "name";

        protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

        protected static ?string $slug = "warehouses/categories";

        protected static ?int $navigationSort = 2;


        public static function getTranslatableLocales(): array
        {
            return config('system.supported_languages', []);
        }

        public static function getNavigationGroup(): ?string
        {
            return __('fields.warehouses');
        }

        public static function getLabel(): ?string
        {
            return __('fields.category');
        }

        public static function getPluralLabel(): ?string
        {
            return __('fields.categories');
        }

        public static function shouldRegisterNavigation(): bool
        {
            return module_enabled('warehouses');
        }

        public static function getNavigationBadge(): ?string
        {
            return static::getModel()::count();
        }

        public static function form(Form $form): Form
        {
            return $form
                ->schema([
                    Forms\Components\Card::make([
                        TextInput::make('name')->label(__('fields.name'))->required(),

                        Select::make('parent_id')
                            ->label(__('fields.category_parent'))
                            ->options(Category::canBecomeParent()->pluck('name', 'id'))
                            ->searchable(),

                        Forms\Components\TextInput::make('sort')
                            ->label(__('fields.sort'))
                            ->required()
                            ->default(1)
                            ->numeric(),

                    ])
                ]);
        }

        public static function table(Tables\Table $table): Tables\Table
        {
            //php artisan make:filament-resource Banner
            return $table
                ->columns([
                    Tables\Columns\TextColumn::make('sort')
                        ->label(__('fields.sort'))
                        ->getStateUsing(function ($record) {
                            return "#" . $record->sort;
                        }),
                    Tables\Columns\TextColumn::make('name')->label(__('fields.name')),
                    Tables\Columns\TextColumn::make('parent.name')->label(__('fields.category_parent')),
                    Tables\Columns\TextColumn::make('all_children_count')->counts('allChildren')->label(__('fields.category_subs')),
                    Tables\Columns\TextColumn::make('products_count')->counts('products')->label(__('fields.products')),

                    Tables\Columns\TextColumn::make('created_at')
                        ->label(__('fields.created_at'))
                        ->dateTime('M j, Y')
                        ->sortable(),
                ])->actions([

                    Tables\Actions\ActionGroup::make([
                        Tables\Actions\EditAction::make(),
                        Tables\Actions\DeleteAction::make()
                            ->action(function (Category $record) {
                                if ($record->children->isNotEmpty()) {
                                    Notification::make()
                                        ->title("Item has children and cannot be deleted.")
                                        ->warning()
                                        ->send();
                                    return;
                                }else if ($record->products->isNotEmpty()) {
                                    Notification::make()
                                        ->title("Item has products and cannot be deleted.")
                                        ->warning()
                                        ->send();
                                    return;
                                }

                                $record->delete();

                                Notification::make()
                                    ->title("Item deleted")
                                    ->success()
                                    ->send();

                                if ($record->parent) {
                                    Cache::clear("sub-of-" . $record->parent->slug);
                                }
                            })
                            ->requiresConfirmation()
                            ->color('danger'),
                    ]),

                ])
                ->filters([
                    //
                ]);
        }

        public static function getRelations(): array
        {
            return [
                RelationManagers\ChildrenRelationManager::class,
                RelationManagers\ProductsRelationManager::class,
            ];
        }

        public static function getPages(): array
        {
            return [
                'index' => Pages\ListCategories::route('/'),
                'create' => Pages\CreateCategory::route('/create'),
                'edit' => Pages\EditCategory::route('/{record}/edit'),
            ];
        }

        public static function getEloquentQuery(): Builder
        {
            return parent::getEloquentQuery()->with(['parent', 'children', "allChildren"])->orderBy("sort");
        }


        public static function getWidgets(): array
        {
            return [
                CategoryResource\Widgets\CategoryOverview::class
            ];
        }
    }
