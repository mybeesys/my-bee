<?php

    namespace App\Filament\Resources;

    use App\Filament\Resources\ClientResource\Pages;
    use App\Filament\Resources\ClientResource\RelationManagers;
    use App\Models\AccReference;
    use App\Models\Client;
    use App\Models\ClientReport;
    use App\Models\Representative;
    use Filament\Facades\Filament;
    use Filament\Forms;
    use Filament\Resources\Resource;
    use Filament\Tables;
    use Illuminate\Database\Eloquent\Builder;
    use Filament\Forms\Form;
    use Filament\Tables\Table;


    class ClientResource extends Resource
    {

        protected static ?string $model = Client::class;

        protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

        protected static ?string $slug = "crm/clients";

        protected static ?int $navigationSort = 1;

        public static function getNavigationGroup(): ?string
        {
            return __('fields.crm');
        }

        public static function getLabel(): ?string
        {
            return __('fields.client');
        }

        public static function getPluralLabel(): ?string
        {
            return __('fields.clients');
        }

        public static function shouldRegisterNavigation(): bool
        {
            return module_enabled('crm');
        }

        public static function getNavigationBadge(): ?string
        {
            return static::getModel()::hideAnonymousClient()->count();
        }

        public static function form(Form $form): Form
        {
            return $form
                ->schema(static::getFormSchema(Forms\Components\Card::class))
                ->columns([
                    'sm' => 3,
                    'lg' => null,
                ]);
        }

        public static function getFormSchema(string $layout = Forms\Components\Grid::class): array
        {
            return [
                Forms\Components\Group::make()
                    ->schema([
                        $layout::make()
                            ->schema([
                                Forms\Components\TextInput::make('name')
                                    ->label(__('fields.name'))
                                    ->autofocus()
                                    ->required(),
                                Forms\Components\TextInput::make('phone')
                                    ->label(__('fields.phone'))
                                    ->required(),

                                Forms\Components\TextInput::make('address')
                                    ->label(__('fields.address')),

                                Forms\Components\TextInput::make('company')
                                    ->label(__('fields.company')),

                                Forms\Components\TextInput::make('email')
                                    ->label(__('fields.email')),

                                Forms\Components\Select::make('representative_id')
                                    ->label(__('fields.representative'))
                                    ->searchable()
                                    ->options(Representative::pluck('name', 'id')),

                            ])->columns(2),

                        $layout::make()
                            ->schema([
                                Forms\Components\RichEditor::make('notes')->label(__('fields.notes')),
                            ]),
                    ])->columnSpan([
                        'sm' => 3,
                    ]),
            ];
        }

        public static function table(Table $table): Table
        {
            return $table
                ->columns([
                    Tables\Columns\TextColumn::make('name')->label(__('fields.name'))->searchable(),
                    Tables\Columns\TextColumn::make('phone')->label(__('fields.phone'))->searchable(),
                    Tables\Columns\TextColumn::make('address')->label(__('fields.address'))->searchable(),
                    Tables\Columns\TextColumn::make('company')->label(__('fields.company'))->searchable(),
                    Tables\Columns\TextColumn::make('email')->label(__('fields.email'))->searchable(),
                    Tables\Columns\TextColumn::make('representative.name')->label(__('fields.representative')),

                    Tables\Columns\TextColumn::make('reports_count')->label('البلاغات')->counts('reports'),

                    Tables\Columns\TextColumn::make('updated_at')
                        ->label(__('fields.updated_at'))
                        ->dateTime('M j, Y')
                        ->sortable(),
                    Tables\Columns\TextColumn::make('created_at')
                        ->label(__('fields.created_at'))
                        ->dateTime('M j, Y')
                        ->sortable(),
                ])
                ->filters([
                    //
                ])
                ->actions([
                    Tables\Actions\ActionGroup::make([
                        Tables\Actions\EditAction::make(),

//                    Tables\Actions\Action::make('add_report')
//                        ->label(__('fields.creat_report'))
//                        ->modalWidth('lg')
//                        ->icon('heroicon-o-pencil')
//                        ->requiresConfirmation()
//                        ->color('danger')
//                        ->form([
//                            Forms\Components\Card::make([
//                                Forms\Components\TextInput::make('client')
//                                    ->dehydrated(0)
//                                    ->afterStateHydrated(function ($record, Forms\Set $set) {
//                                        $set('client', $record->name);
//                                    })
//                                    ->visible(fn(Forms\Get $get) => $get('client') != null)
//                                    ->reactive()
//                                    ->label(__('fields.client')),
//
//                                Forms\Components\TextInput::make('subject')
//                                    ->label(__('fields.subject'))
//                                    ->required(),
//                            ]),
//
//                            Forms\Components\Card::make([
//                                Forms\Components\MarkdownEditor::make('report')
//                                    ->label(__('fields.report_details'))
//                                    ->required(),
////                                Forms\Components\MarkdownEditor::make('notes')
////                                    ->label(__('fields.notes')),
//                            ]),
//
////                            Forms\Components\Card::make([
////
////                            ]),
//
////                            Forms\Components\Card::make([
////                                Forms\Components\KeyValue::make('attributes')
////                                    ->label(__('fields.extra_fields'))
////                                    ->reorderable()
////                                    ->keyLabel(__('fields.extra_fields_key'))
////                                    ->valueLabel(__('fields.extra_fields_value'))
////                                    ->keyPlaceholder('')
////                                    ->valuePlaceholder(''),
////                            ]),
//                        ])
//                        ->action(function ($record, array $data) {
//
//                            $data['status'] = "pending";
//                            $data['client_id'] = $record->id;
//                            $data['user_id'] = auth()->id();
//
//                            ClientReport::create($data);
//
//
//                        })

                    ]),
                ])
                ->bulkActions([
                    Tables\Actions\DeleteBulkAction::make(),
                ])->deferLoading();
        }

        public static function getEloquentQuery(): Builder
        {
            return parent::getEloquentQuery()->hideAnonymousClient()->with(['representative', 'reports'])->latest(); // TODO: Change the autogenerated stub
        }

        public static function getRelations(): array
        {
            return [
                RelationManagers\ClientReportRelationManager::class
            ];
        }

        public static function getPages(): array
        {
            return [
                'index' => Pages\ListClients::route('/'),
                'create' => Pages\CreateClient::route('/create'),
                'edit' => Pages\EditClient::route('/{record}/edit'),
            ];
        }
    }
