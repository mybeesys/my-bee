<?php

    namespace App\Filament\Resources;

    use App\Filament\Resources\PurchaseInvoiceResource\Pages;
    use App\Filament\Resources\PurchaseInvoiceResource\RelationManagers;
    use App\Models\Acc4;
    use App\Models\Invoice;
    use App\Models\InvoiceStatus;
    use App\Models\Product;
    use App\Models\Supplier;
    use App\Models\Warehouse;
    use App\Services\InvoiceService;
    use Filament\Facades\Filament;
    use Filament\Forms;
    use Filament\Notifications\Actions\Action;
    use Filament\Notifications\Notification;
    use Filament\Resources\Resource;
    use Filament\Tables;
    use Illuminate\Database\Eloquent\Builder;
    use Illuminate\Support\Facades\DB;

    class PurchaseInvoiceResource extends Resource
    {
        protected static ?string $model = Invoice::class;
        protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';
        protected static ?int $navigationSort = 2;
        protected static ?string $slug = "purchases/invoices";

        public static function getNavigationGroup(): ?string
        {
            return __('fields.purchases');
        }

        public static function getLabel(): ?string
        {
            return __('fields.purchases_invoice');
        }


        public static function getPluralLabel(): ?string
        {
            return __('fields.purchases_invoices');
        }

        public static function shouldRegisterNavigation(): bool
        {
            return module_enabled('purchases');
        }

        public static function getNavigationBadge(): ?string
        {
            return Invoice::purchases()->count();
        }

        public static function form(Forms\Form $form): Forms\Form
        {
            return $form
                ->schema(static::getFormSchema(Forms\Components\Card::class))
                ->columns([
                    'sm' => 3,
                    'lg' => null,
                ]);
        }

        public static function getFormSchema(string $layout = Forms\Components\Grid::class): array
        {
            return [
                Forms\Components\Group::make()
                    ->schema([
                    ]),
            ];
        }

        public static function table(Tables\Table $table): Tables\Table
        {
            return $table
                ->columns([
                    Tables\Columns\TextColumn::make('no')
                        ->label(__('fields.invoice_no'))
                        ->searchable(),
                    Tables\Columns\TextColumn::make('invoice_status_id')
                        ->getStateUsing(function ($record) {
                            return $record->invoiceStatus->name;
                        })
                        ->label(__('fields.status'))
                        ->searchable(),
                    Tables\Columns\TextColumn::make('date')
                        ->label(__('fields.date'))
                        ->dateTime('M j, Y')
                        ->searchable(),
                    Tables\Columns\TextColumn::make('supplier.name')
                        ->label(__('fields.supplier'))
                        ->searchable(),
                    Tables\Columns\TextColumn::make('exchange_rate')
                        ->label(__('fields.exchange_rate'))
                        ->searchable(),
                    Tables\Columns\TextColumn::make('purchases_total_sdg')
                        ->label(__('fields.total_purchases_sdg'))
                        ->getStateUsing(function ($record) {
                            return number_format($record->getItemsCost("SDG"), 2) . ' SDG';
                        }),
                    Tables\Columns\TextColumn::make('purchases_total_usd')
                        ->label(__('fields.total_purchases_usd'))
                        ->getStateUsing(function ($record) {
                            return number_format($record->getItemsCost("USD"), 2) . ' USD';
                        }),
                    Tables\Columns\TextColumn::make('additional_costs_total')
                        ->label(__('fields.additional_costs'))
                        ->getStateUsing(function ($record) {
                            return number_format($record->getAdditionalCosts("SDG"), 2) . ' SDG';
                        }),
                ])
                ->filters([
                    Tables\Filters\SelectFilter::make('invoice_status_id')
                        ->label(__('fields.status'))
                        ->options(InvoiceStatus::where('type', 'purchases')->pluck('name', 'id'))
                ])
                ->actions([
                    Tables\Actions\ActionGroup::make([
                        Tables\Actions\EditAction::make(),

                        Tables\Actions\Action::make('download_invoice')
                            ->label(__('fields.download_invoice'))
                            ->icon('heroicon-o-arrow-down-tray')
                            ->color('success')
                            ->action(function (Invoice $record) {
                                try {
                                    $invoice = (new InvoiceService())
                                        ->filePath('invoices/purchases')
                                        ->getInvoice($record, 0, 0, [
                                            'Total paid' => $record->total_paid['sdg'],
                                        ]);

                                    Notification::make()
                                        ->title('Invoice download completed')
                                        ->success()
                                        ->persistent()
                                        ->actions([
                                            Action::make('view')
                                                ->label('View file')
                                                ->button()
                                                ->url($invoice->url(), shouldOpenInNewTab: true)
                                        ])
                                        ->send();
                                }catch (\Exception $exception)
                                {
                                    Notification::make()
                                        ->title('Unable to download invoice')
                                        ->body($exception->getMessage())
                                        ->danger()
                                        ->persistent()
                                        ->send();
                                }

                            }),

                        Tables\Actions\Action::make('status')
                            ->visible(function ($record) {
                                return $record->locked_at == null;
                            })
                            ->color('warning')
                            ->icon('heroicon-o-pencil-square')
                            ->label(__('fields.change_status'))
                            ->modalWidth('lg')
                            ->requiresConfirmation()
                            ->form([
                                Forms\Components\Section::make([
                                    Forms\Components\Select::make('status')
                                        ->reactive()
                                        ->label(__('fields.status'))
                                        ->options(InvoiceStatus::where('type', 'purchases')->pluck('name', 'id'))
                                        ->required()
                                        ->afterStateHydrated(function (Forms\Components\Select $component, $record) {
                                            $component->state($record->invoice_status_id);
                                        }),

                                    Forms\Components\TextInput::make('info')
                                        ->visible(fn(Forms\Get $get) => $get('status') == 3)
                                        ->extraAttributes(['class' => 'text-danger-700'])
                                        ->default(__('fields.invoice_will_be_locked_after_this_action'))
                                        ->disabled(1)
                                        ->label(__('fields.alert_info')),
                                ])
                            ])
                            ->action(function ($record, array $data) {

                                try {

                                    DB::beginTransaction();

                                    if ($data['status'] == 3) {
                                        if (!can_lock_invoice())
                                        {
                                            Notification::make()
                                                ->title(__('fields.insufficient_permission'))
                                                ->warning()
                                                ->send();
                                        }

                                        $record->approveAndStockWarehouse();
                                        $record->update(['invoice_status_id' => $data['status'], 'locked_at' => now()]);
                                    } else {
                                        $record->update(['invoice_status_id' => $data['status']]);
                                    }

                                    Notification::make()
                                        ->title(__('fields.alert_info'))
                                        ->body(__('fields.invoice_updated'))
                                        ->warning()
                                        ->persistent()
                                        ->send();

                                    DB::commit();

                                } catch (\Exception $exception) {
                                    DB::rollBack();
                                }

                            }),

                    ]),
                ])
                ->filters([
                ])
                ->bulkActions([
                ]);
        }

        public static function getRelations(): array
        {
            return [
                //
            ];
        }

        public static function getPages(): array
        {
            return [
                'index' => Pages\ListPurchaseInvoices::route('/'),
                'create' => Pages\CreateCustomPurchaseInvoice::route('/create'),
                'edit' => Pages\EditCustomPurchaseInvoice::route('/{record}/edit'),
            ];
        }

        public static function getEloquentQuery(): Builder
        {
            return parent::getEloquentQuery()
                ->purchases()
                ->with(
                    [
                        'invoiceStatus',
                        'items',
                        'payments',
                        'client',
                        'representative',
                        'supplier',
                        'user',
                        'reviewedBy',
                        'additionalCosts',
                    ])->latest();
        }
    }
