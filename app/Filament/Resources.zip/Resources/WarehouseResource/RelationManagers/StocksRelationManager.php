<?php

    namespace App\Filament\Resources\WarehouseResource\RelationManagers;

    use App\Models\ItemStock;
    use App\Models\Product;
    use Filament\Facades\Filament;
    use Filament\Forms;
    use Filament\Notifications\Notification;
    use Filament\Resources\RelationManagers\RelationManager;
    use Filament\Tables;
    use Illuminate\Database\Eloquent\Builder;
    use Illuminate\Database\Eloquent\SoftDeletingScope;
    use Illuminate\Support\HtmlString;

    class StocksRelationManager extends RelationManager
    {
        protected static string $relationship = 'stocks';

        protected static ?string $recordTitleAttribute = 'name';

//        public static function getTitle(): string
//        {
//            return 'المخزون';
//        }

        public function form(Forms\Form $form): Forms\Form
        {
            return $form
                ->schema([
//                Forms\Components\TextInput::make('exchange_rate')
//                    ->label('سعر الصرف')
//                    ->required(),
//
//                Forms\Components\TextInput::make('stock')
//                    ->label('الكمية')
//                    ->rules(['integer', 'min:1', 'max:10000000'])
//                    ->required(),
//
//                Forms\Components\TextInput::make('available_stock')
//                    ->label('الكمية المتوفرة')
//                    ->gt('0')
//                    ->numeric()
//                    ->rules(['integer', 'min:1', 'max:10000000'])
//                    ->required(),
//
//                Forms\Components\TextInput::make('cost_per_item_sdg')
//                    ->label('سعر الحبة بالجنية')
//                    ->reactive()
//                    ->numeric()
//                    ->rules(['regex:/^\d{1,6}(\.\d{0,2})?$/'])
//                    ->required(),
//
//                Forms\Components\TextInput::make('cost_per_item_usd')
//                    ->label('سعر الحبة بالدولار')
//                    ->numeric()
//                    ->rules(['regex:/^\d{1,6}(\.\d{0,2})?$/'])
//                    ->required(),
//
//                Forms\Components\TextInput::make('retail_price_sdg')
//                    ->label('سعر الحبة للمستهلك بالجنية')
//                    ->numeric()
//                    ->rules(['regex:/^\d{1,6}(\.\d{0,2})?$/'])
//                    ->required(),
//
//                Forms\Components\RichEditor::make('description')
//                    ->label(__('fields.description')),
                ]);
        }

        public function table(Tables\Table $table): Tables\Table
        {
            return $table
                ->columns([
                    Tables\Columns\TextColumn::make('item.name')
                        ->label(__('fields.product')),

                    Tables\Columns\TextColumn::make('type')
                        ->label(__('fields.type'))
                        ->getStateUsing(function ($record) {
                            $local = app()->getLocale();

                            if ($record->type == 'purchase') {
                                return $local == "en" ? "Purchases" : "مشتريات";
                            } else if ($record->type == 'opening-stock') {
                                return $local == "en" ? "Opening stock" : "مخزون إفتتاحي";
                            } else if ($record->type == 'moved') {
                                return $local == "en" ? "Moved" : "مخزون منقول";
                            }
                            return 'unknown';
                        }),

                    Tables\Columns\BooleanColumn::make('available')
                        ->label(__('fields.available_stock'))
                        ->getStateUsing(function ($record) {
                            return $record->qty_in > $record->qty_out;
                        }),
                    Tables\Columns\TextColumn::make('qty_in')
                        ->label(__('fields.total_stock')),

                    Tables\Columns\TextColumn::make('sold')
                        ->label(__('fields.sold_stock'))
                        ->getStateUsing(function ($record) {
                            return $record->qty_out;
                        }),

                    Tables\Columns\TextColumn::make('qty_moved')
                        ->label(__('fields.moved'))
                        ->action(function (ItemStock $record): void {

                            $stock = ItemStock::with('warehouse')->where('stock_id', $record->id)->first();

                            if ($stock) {
                                $name = $stock->warehouse->name;
                                $message = app()->getLocale() == "en" ? "This stock moved to ($name)" : "تم نقل المخزون إلي ($name)";
                                Notification::make()
                                    ->title($message)
                                    ->warning()
                                    ->send();
                            }
                        }),

                    Tables\Columns\TextColumn::make('available_stock')
                        ->label(__('fields.available_stock'))
                        ->getStateUsing(function ($record) {
                            return $record->available;
                        }),

                    Tables\Columns\TextColumn::make('unit_cost_sdg')
                        ->label(__('fields.unit_cost_sdg'))
                        ->tooltip(function ($record) {
                            return \Tafqeet::inArabic($record->unit_cost_sdg, 'egp');
                        })
                        ->getStateUsing(function ($record) {
                            return number_format($record->unit_cost_sdg, 2) . ' SDG';
                        }),

                    Tables\Columns\TextColumn::make('unit_cost_usd')
                        ->label(__('fields.unit_cost_usd'))
                        ->tooltip(function ($record) {
                            return \Tafqeet::inArabic($record->unit_cost_usd, 'usd');
                        })
                        ->getStateUsing(function ($record) {
                            return number_format($record->unit_cost_usd, 2) . ' USD';
                        }),

                    Tables\Columns\TextColumn::make('unit_retail_sdg')
                        ->label(__('fields.unit_retail_sdg'))
                        ->tooltip(function ($record) {
                            if ($record->item->lastPrice)
                                return \Tafqeet::inArabic($record->item->lastPrice->sdg_price, 'egp');

                            return "-";
                        })
                        ->getStateUsing(function ($record) {
                            if ($record->item->lastPrice)
                                return number_format($record->item->lastPrice->sdg_price, 2) . ' USD';
                            return "-";
                        }),

                    Tables\Columns\TextColumn::make('unit_retail_usd')
                        ->label(__('fields.unit_retail_usd'))
                        ->tooltip(function ($record) {
                            if ($record->item->lastPrice)
                                return \Tafqeet::inArabic($record->item->lastPrice->usd_price, 'usd');

                            return "-";
                        })
                        ->getStateUsing(function ($record) {
                            if ($record->item->lastPrice) {
                                return number_format($record->item->lastPrice->usd_price, 2) . ' USD';
                            }
                            return "-";
                        }),

                    Tables\Columns\TextColumn::make('created_at')
                        ->toggleable()
                        ->label(__('fields.created_at'))
                        ->dateTime('M j, Y')
                        ->sortable(),
                ])
                ->filters([
                    //
                ])
                ->headerActions([
                ])
                ->actions([
//                Tables\Actions\EditAction::make(),
//                Tables\Actions\DeleteAction::make(),
                ])
                ->bulkActions([
                ]);
        }
    }
