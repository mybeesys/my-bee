<?php

namespace App\Filament\Resources\ReceiptVoucherResource\Pages;

use App\Filament\Resources\ReceiptVoucherResource;
use App\Models\Op;
use App\Models\OpType;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateReceiptVoucher extends CreateRecord
{
    protected static string $resource = ReceiptVoucherResource::class;

    protected function mutateFormDataBeforeCreate(array $data): array
    {
        $op = Op::generate(OpType::$RECEIPT_VOUCHER);

        $data['op_id'] = $op->id;
        $data['user_id'] = auth()->id();

        return $data;
    }
}
