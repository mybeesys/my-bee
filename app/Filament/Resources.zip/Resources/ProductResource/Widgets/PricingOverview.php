<?php

    namespace App\Filament\Resources\ProductResource\Widgets;

    use App\Models\ItemPrice;
    use App\Models\ItemStock;
    use App\Models\Product;
    use Filament\Widgets\StatsOverviewWidget as BaseWidget;
    use Filament\Widgets\StatsOverviewWidget\Card;

    class PricingOverview extends BaseWidget
    {

        protected static ?string $pollingInterval = "60s";

        protected function getCards(): array
        {

            $cards = [];

            $missingPrices = Product::whereDoesntHave('lastPrice')->count();

            if ($missingPrices > 0) {
                $cards[] = Card::make(__('fields.none_priced_items'), $missingPrices)
                    ->extraAttributes([
//                        'class' => 'cursor-pointer',
//                        'wire:click' => '$emitUp("viewNonePricedItems", "processed")',
                    ]);
            }

            $total_sdg = 0;
            $total_usd = 0;
            foreach (ItemStock::where('item_type', Product::class)->get() as $stock)
            {
                $total_sdg += $stock->getTotalCost();
                $total_usd += $stock->getTotalCost('usd');
            }

            return array_merge(
                [

                    Card::make(__('fields.total_items_cost_sdg_in_warehouses'), number_format($total_sdg, 2) . ' SDG')
                        ->description(tafqeet($total_sdg, 'egp')),

                    Card::make(__('fields.total_items_cost_usd_in_warehouses'), number_format($total_usd, 2) . ' USD')
                        ->description(tafqeet($total_usd, 'usd')),
                ],
                $cards
            );
        }
    }
