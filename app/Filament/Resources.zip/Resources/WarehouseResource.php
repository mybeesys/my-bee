<?php

    namespace App\Filament\Resources;

    use App\Filament\Resources\ProductResource\Widgets\PricingOverview;
    use App\Filament\Resources\WarehouseResource\Pages;
    use App\Filament\Resources\WarehouseResource\RelationManagers;
    use App\Models\Product;
    use App\Models\ProductStock;
    use App\Models\Warehouse;
    use AymanAlhattami\FilamentPageWithSidebar\FilamentPageSidebar;
    use AymanAlhattami\FilamentPageWithSidebar\PageNavigationItem;
    use Filament\Facades\Filament;
    use Filament\Forms;
    use Filament\Notifications\Notification;
    use Filament\Resources\Form;
    use Filament\Resources\Resource;
    use Filament\Resources\Table;
    use Filament\Tables;
    use Illuminate\Database\Eloquent\Builder;
    use Illuminate\Database\Eloquent\Model;
    use Illuminate\Database\Eloquent\SoftDeletingScope;
    use Illuminate\Support\HtmlString;

    class WarehouseResource extends Resource
    {
        protected static ?string $model = Warehouse::class;

        protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

        protected static ?string $slug = "warehouses/warehouses";

        protected static ?int $navigationSort = 1;

        public static function getNavigationGroup(): ?string
        {
            return __('fields.warehouses');
        }

        public static function getLabel(): ?string
        {
            return __('fields.warehouse');
        }

        public static function getPluralLabel(): ?string
        {
            return __('fields.warehouses');
        }

        public static function shouldRegisterNavigation(): bool
        {
            return module_enabled('warehouses');
        }

        public static function getNavigationBadge(): ?string
        {
            return static::getModel()::count();
        }


        public static function form(Forms\Form $form): Forms\Form
        {
            return $form
                ->schema(static::getFormSchema(Forms\Components\Card::class))
                ->columns([
                    'sm' => 3,
                    'lg' => null,
                ]);
        }

        public static function getFormSchema(string $layout = Forms\Components\Grid::class): array
        {
            return [
                Forms\Components\Group::make()
                    ->schema([
                        $layout::make()
                            ->schema([
                                Forms\Components\TextInput::make('name')
                                    ->label(__('fields.name'))
                                    ->autofocus()
                                    ->required(),
                                Forms\Components\TextInput::make('address')
                                    ->label(__('fields.address')),
                                Forms\Components\TextInput::make('phone')
                                    ->label(__('fields.phone')),
                                Forms\Components\RichEditor::make('description')
                                    ->label(__('fields.description')),
                            ]),
                    ])->columnSpan([
                        'sm' => 3,
                    ]),
            ];
        }

        public static function table(Tables\Table $table): Tables\Table
        {
            return $table
                ->columns([
                    Tables\Columns\TextColumn::make('name')
                        ->label(__('fields.name'))
                        ->extraAttributes(['class' => 'text-success-700'])
                        ->searchable(),
                    Tables\Columns\TextColumn::make('address')
                        ->label(__('fields.address'))
                        ->searchable(),
                    Tables\Columns\TextColumn::make('phone')
                        ->label(__('fields.phone'))
                        ->searchable(),
                    Tables\Columns\TextColumn::make('stocks')
                        ->label(__('fields.products'))
                        ->getStateUsing(function ($record) {
                            return $record->stocks->pluck('item_id')->unique()->count();
                        }),

                    Tables\Columns\TextColumn::make('warehouse_items_cost_sdg')
                        ->label(__('fields.warehouse_items_cost_sdg'))
                        ->tooltip(function ($record) {
                            $total_sdg = 0;
                            foreach ($record->stocks as $stock)
                            {
                                $total_sdg += $stock->getTotalCost();
                            }
                            return tafqeet($total_sdg, 'egp');
                        })
                        ->getStateUsing(function (Warehouse $record) {
                            $total_sdg = 0;
                            foreach ($record->stocks as $stock)
                            {
                                $total_sdg += $stock->getTotalCost();
                            }
                            return number_format($total_sdg, 2) . ' SDG';
                        }),

                    Tables\Columns\TextColumn::make('warehouse_items_cost_usd')
                        ->label(__('fields.warehouse_items_cost_usd'))
                        ->tooltip(function ($record) {
                            $total_usd = 0;
                            foreach ($record->stocks as $stock)
                            {
                                $total_usd += $stock->getTotalCost('usd');
                            }
                            return tafqeet($total_usd, 'usd');
                        })
                        ->getStateUsing(function (Warehouse $record) {
                            $total_usd = 0;
                            foreach ($record->stocks as $stock)
                            {
                                $total_usd += $stock->getTotalCost('usd');
                            }
                            return number_format($total_usd, 2) . ' USD';
                        }),
//                    Tables\Columns\TextColumn::make('description')
//                        ->label(__('fields.description'))
//                        ->getStateUsing(function ($record) {
//                            return new HtmlString($record->description);
//                        })
//                        ->searchable(),
                    Tables\Columns\TextColumn::make('created_at')
                        ->label(__('fields.created_at'))
                        ->dateTime('M j, Y')
                        ->sortable(),
                ])
                ->filters([
                    //
                ])
                ->actions([
                    Tables\Actions\ActionGroup::make([
                        Tables\Actions\EditAction::make(),

                        Tables\Actions\Action::make('delete')
                            ->label(__('fields.delete'))
                            ->icon('heroicon-o-trash')
                            ->action(function (Warehouse $record) {
                                if ($record->stocks->isNotEmpty()) {
                                    Notification::make()
                                        ->title(__('fields.record_in_use_alert'))
                                        ->warning()
                                        ->send();
                                    return;
                                }

                                $record->delete();

                                Notification::make()
                                    ->title(__('fields.record_deleted_alert'))
                                    ->success()
                                    ->send();

                            })
                            ->requiresConfirmation()
                            ->color('danger'),
                    ]),

                ])
                ->bulkActions([
//                Tables\Actions\DeleteBulkAction::make(),
                ])->deferLoading();
        }

        public static function getRelations(): array
        {
            return [
                RelationManagers\StocksRelationManager::class,
            ];
        }

        public static function getWidgets(): array
        {
            return [
                PricingOverview::class,
            ];
        }

        public static function getEloquentQuery(): Builder
        {
            return parent::getEloquentQuery()->with(['stocks.item.lastPrice', 'stocks.stock'])->latest(); // TODO: Change the autogenerated stub
        }

        public static function getPages(): array
        {
            return [
                'index' => Pages\ListWarehouses::route('/'),
                'create' => Pages\CreateWarehouse::route('/create'),
                'edit' => Pages\EditWarehouse::route('/{record}/edit'),
            ];
        }
    }
