<?php

    namespace App\Filament\Resources\ClientResource\RelationManagers;

    use Filament\Facades\Filament;
    use Filament\Forms;
    use Filament\Notifications\Notification;
    use Filament\Resources\RelationManagers\RelationManager;
    use Filament\Tables;
    use Filament\Forms\Form;


    class ClientReportRelationManager extends RelationManager
    {
        protected static string $relationship = 'reports';

        protected static ?string $recordTitleAttribute = 'name';

        protected static ?string $label = 'بلاغ';

//        public static function getTitle(): string
//        {
//            return "البلاغات";
//        }

        public function form(Form $form): Form
        {
            return $form
                ->schema([

                    Forms\Components\Card::make([
                        Forms\Components\TextInput::make('client')
                            ->disabled(1)
                            ->dehydrated(0)
                            ->visible(fn(Forms\Get $get) => $get('client') != null)
                            ->reactive()
                            ->label('العميل'),

                        Forms\Components\TextInput::make('subject')
                            ->reactive()
                            ->afterStateHydrated(function (Tables\Contracts\HasTable $livewire, Forms\Set $set) {
                                $name = $livewire->getRelationship()->getParent()->name;
                                $set('client', $name);
                            })
                            ->label('الموضوع')
                            ->required(),
                    ]),

                    Forms\Components\Card::make([
                        Forms\Components\MarkdownEditor::make('report')
                            ->label('تفاصيل البلاغ')
                            ->required(),
                    ]),

                    Forms\Components\Card::make([
                        Forms\Components\MarkdownEditor::make('notes')
                            ->label('ملاحظات'),
                    ]),

                    Forms\Components\Card::make([
                        Forms\Components\KeyValue::make('attributes')
                            ->label('حقول إضافية')
                            ->reorderable()
                            ->keyLabel('إسم الحقل')
                            ->valueLabel('القيمة')
                            ->keyPlaceholder('')
                            ->valuePlaceholder(''),
                    ]),
                ]);
        }


        public function table(Tables\Table $table): Tables\Table
        {
            return $table
                ->columns([
                    Tables\Columns\TextColumn::make('subject')
                        ->searchable()
                        ->label('الموضوع'),
                    Tables\Columns\BadgeColumn::make('status')
                        ->getStateUsing(function ($record) {
                            if ($record->status == 'pending') {
                                return 'جديد';
                            }
                            if ($record->status == 'processing') {
                                return 'قيد المعالجة';
                            }

                            if ($record->status == 'processed') {
                                return 'تمت المعالجة';
                            }

                        })
                        ->searchable()
                        ->colors([
                            'primary',
                            'success' => 'تمت المعالجة',
                            'danger' => 'قيد المعالجة',
                        ])
                        ->label('الحالة'),

                    Tables\Columns\TextColumn::make('report')
                        ->searchable()
                        ->label('تفاصيل البلاغ'),

                    Tables\Columns\TextColumn::make('notes')
                        ->label('ملاحظات')
                        ->getStateUsing(function ($record) {
                            return $record->notes;
                        }),

                    Tables\Columns\TextColumn::make('processed_at')
                        ->toggleable()
                        ->label('تاريخ المعالجة')
                        ->dateTime('M j, Y H:i')
                        ->sortable(),

                    Tables\Columns\TextColumn::make('created_at')
                        ->toggleable()
                        ->label(__('fields.created_at'))
                        ->dateTime('M j, Y H:i')
                        ->sortable(),
                ])
                ->filters([
                ])
                ->headerActions([
                    Tables\Actions\CreateAction::make()
                        ->mutateFormDataUsing(function (Tables\Contracts\HasRelationshipTable $livewire, array $data): array {

                            $client = $livewire->getRelationship()->getParent();

                            $data['status'] = "pending";
                            $data['client_id'] = $client->id;
                            $data['user_id'] = auth()->id();

                            return $data;
                        })
                ])
                ->actions([
                    Tables\Actions\ActionGroup::make([
                        Tables\Actions\EditAction::make(),
                        Tables\Actions\DeleteAction::make(),
                        Tables\Actions\Action::make('change_state')
                            ->label('تغيير الحالة')
                            ->modalWidth('lg')
                            ->icon('heroicon-o-pencil')
                            ->requiresConfirmation()
                            ->color('danger')
                            ->form([
                                Forms\Components\Select::make('status')
                                    ->label('الحالة')
                                    ->options(function () {
                                        return [
                                            'processing' => 'قيد المعالجة',
                                            'processed' => 'تمت المعالجة'
                                        ];
                                    })
                                    ->required(),
                            ])
                            ->action(function ($record, array $data) {

                                if ($data['status'] == 'processed') {
                                    $record->update(['status' => $data['status'], 'processed_at' => now()]);

                                } else {
                                    $record->update(['status' => $data['status'], 'processed_at' => null]);
                                }

                                Notification::make()
                                    ->title('تم تغيير الحالة بنجاح')
                                    ->success()
                                    ->send();

                            })
                    ]),
                ])
                ->bulkActions([
                ]);
        }
    }
