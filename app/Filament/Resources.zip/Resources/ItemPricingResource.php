<?php

    namespace App\Filament\Resources;

    use App\Filament\Resources\ItemPricingResource\Pages;
    use App\Filament\Resources\ItemPricingResource\RelationManagers;
    use App\Filament\Resources\ProductResource\Widgets\MissingPricingOverview;
    use App\Filament\Resources\ProductResource\Widgets\PricingOverview;
    use App\Models\Acc4;
    use App\Models\ItemPrice;
    use App\Models\ItemPricing;
    use App\Models\Product;
    use Filament\Forms;
    use Filament\Resources\Form;
    use Filament\Resources\Resource;
    use Filament\Resources\Table;
    use Filament\Tables;
    use Illuminate\Database\Eloquent\Builder;
    use Illuminate\Database\Eloquent\Model;
    use Illuminate\Database\Eloquent\SoftDeletingScope;
    use Filament\Facades\Filament;

    class ItemPricingResource extends Resource
    {
        protected static ?string $model = ItemPrice::class;

        protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

        protected static ?string $slug = "warehouses/items-prices";

        protected static ?int $navigationSort = 4;

        public static function getNavigationGroup(): ?string
        {
            return __('fields.warehouses');
        }

        public static function getLabel(): ?string
        {
            return __('fields.item_price');
        }

        public static function getPluralLabel(): ?string
        {
            return __('fields.items_prices');
        }

        public static function shouldRegisterNavigation(): bool
        {
            return module_enabled('warehouses');
        }

        public static function getNavigationBadge(): ?string
        {
            return static::getModel()::count();
        }

        public static function form(Forms\Form $form): Forms\Form
        {
            return $form
                ->schema([
                    Forms\Components\Card::make()->schema([
                        Forms\Components\Select::make('acc4_code')
                            ->label(__('fields.product'))
                            ->required()
                            ->reactive()
                            ->searchable()
                            ->options(Acc4::asOptions(Product::class))
                            ->afterStateHydrated(function (Forms\Set $set, $record){
                                $set('last_pricing_date', "-");
                                $set('last_pricing_sdg', "-");
                                $set('last_pricing_usd', "-");

                                $set('last_stock_unit_cost_sdg', "-");
                                $set('last_stock_unit_cost_usd', "-");

                                if($record)
                                {
                                    $product = $record->acc4->item;
                                    $lastPriceDate = $product->lastPrice == null ? "-" : $product->lastPrice->date->format('d-m-Y');
                                    $lastPriceSDG = $product->lastPrice == null ? "-" : number_format($product->lastPrice->sdg_price, 2);
                                    $lastPriceUSD = $product->lastPrice == null ? "-" : number_format($product->lastPrice->usd_price, 2);

                                    $lasStockUnitCostSDG = $product->lastStock == null ? "-" : number_format($product->lastStock->unit_cost_sdg, 2);
                                    $lasStockUnitCostUSD = $product->lastStock == null ? "-" : number_format($product->lastStock->unit_cost_usd, 2);

                                    $set('last_pricing_date', $lastPriceDate);
                                    $set('last_pricing_sdg', $lastPriceSDG);
                                    $set('last_pricing_usd', $lastPriceUSD);

                                    $set('last_stock_unit_cost_sdg', $lasStockUnitCostSDG);
                                    $set('last_stock_unit_cost_usd', $lasStockUnitCostUSD);

                                    if($product->lastStock)
                                    $set('profit', number_format(profit_percent($product->lastPrice->sdg_price, $product->lastStock->unit_cost_sdg), 2));

                                }
                            })
                            ->afterStateUpdated(function (Forms\Set $set, $state) {

                                $set('last_pricing_date', "-");
                                $set('last_pricing_sdg', "-");
                                $set('last_pricing_usd', "-");

                                $set('last_stock_unit_cost_sdg', "-");
                                $set('last_stock_unit_cost_usd', "-");
                                if ($state) {
                                    $product = Acc4::with(['item.lastPrice', 'item.lastStock'])->find($state)->item;

                                    $lastPriceDate = $product->lastPrice == null ? "-" : $product->lastPrice->date->format('d-m-Y');
                                    $lastPriceSDG = $product->lastPrice == null ? "-" : number_format($product->lastPrice->sdg_price, 2);
                                    $lastPriceUSD = $product->lastPrice == null ? "-" : number_format($product->lastPrice->usd_price, 2);

                                    $lasStockUnitCostSDG = $product->lastStock == null ? "-" : number_format($product->lastStock->unit_cost_sdg, 2);
                                    $lasStockUnitCostUSD = $product->lastStock == null ? "-" : number_format($product->lastStock->unit_cost_usd, 2);

                                    $set('last_pricing_date', $lastPriceDate);
                                    $set('last_pricing_sdg', $lastPriceSDG);
                                    $set('last_pricing_usd', $lastPriceUSD);

                                    $set('last_stock_unit_cost_sdg', $lasStockUnitCostSDG);
                                    $set('last_stock_unit_cost_usd', $lasStockUnitCostUSD);
                                }
                            }),


                        Forms\Components\TextInput::make('last_stock_unit_cost_sdg')
                            ->dehydrated(false)
                            ->label(__('fields.last_stock_unit_cost_sdg'))
                            ->helperText(function ($state) {
                                return tafqeet($state, 'egp');
                            })
                            ->disabled(1),

                        Forms\Components\TextInput::make('last_stock_unit_cost_usd')
                            ->dehydrated(false)
                            ->label(__('fields.last_stock_unit_cost_usd'))
                            ->helperText(function ($state) {
                                return tafqeet($state, 'usd');
                            })
                            ->disabled(1),

                        Forms\Components\TextInput::make('last_pricing_date')
                            ->dehydrated(false)
                            ->label(__('fields.last_pricing_date'))
                            ->disabled(1),

                        Forms\Components\TextInput::make('last_pricing_sdg')
                            ->dehydrated(false)
                            ->label(__('fields.last_pricing_sdg'))
                            ->helperText(function ($state) {
                                return tafqeet($state, 'egp');
                            })
                            ->disabled(1),

                        Forms\Components\TextInput::make('last_pricing_usd')
                            ->dehydrated(false)
                            ->label(__('fields.last_pricing_usd'))
                            ->helperText(function ($state) {
                                return tafqeet($state, 'usd');
                            })
                            ->disabled(1),

                        Forms\Components\TextInput::make('exchange_rate')
                            ->label(__('fields.exchange_rate'))
                            ->required()
                            ->minValue(1)
                            ->maxValue(99000000)
                            ->afterStateHydrated(function (Forms\Components\TextInput $component) {
                                $component->state(ex_rate());
                            }),

                        Forms\Components\TextInput::make('sdg_price')
                            ->reactive()
                            ->label(__('fields.price_sdg'))
                            ->required()
                            ->numeric()
                            ->minValue(1)
                            ->maxValue(99000000)
                            ->helperText(function ($state) {
                                return tafqeet($state, 'egp');
                            })
                            ->afterStateUpdated(function (Forms\Components\TextInput $component, $state, Forms\Get $get, Forms\Set $set) {
                                $set('profit', '-');
                                $ex_rate = $get('exchange_rate');

                                if ($state and $ex_rate and $state > 0 and $ex_rate > 0 and (is_numeric($state) or is_float($state))
                                    and (is_numeric($ex_rate) or is_float($ex_rate))) {
                                    $set('usd_price', number_format($state / $ex_rate, 2, '.', ''));

                                    $unit_cost_sdg = $get('last_stock_unit_cost_sdg');
                                    if ($unit_cost_sdg) {
                                        $unit_cost_sdg = \Str::replace(',', '', $unit_cost_sdg);

                                        $profit = profit_percent($state, $unit_cost_sdg);

                                        if($profit > 0)
                                        {
                                            $set('profit', number_format($profit, 2));
                                        }else{
                                            $set('profit', "-");
                                        }
                                    }
                                }
                            }),

                        Forms\Components\TextInput::make('usd_price')
                            ->reactive()
                            ->label(__('fields.price_usd'))
                            ->required()
                            ->numeric()
                            ->maxValue(99000000)
                            ->helperText(function ($state) {
                                return tafqeet($state, 'usd');
                            })
                            ->afterStateUpdated(function (Forms\Components\TextInput $component, $state, Forms\Get $get, Forms\Set $set) {
                                $set('profit', '-');
                                $ex_rate = $get('exchange_rate');

                                if ($state and $ex_rate and $state > 0 and $ex_rate > 0 and (is_numeric($state) or is_float($state))
                                    and (is_numeric($ex_rate) or is_float($ex_rate))) {
                                    $set('sdg_price', number_format($state * $ex_rate, 2, '.', ''));

                                    $unit_cost_usd = $get('last_stock_unit_cost_usd');
                                    if ($unit_cost_usd) {
                                        $unit_cost_usd = \Str::replace(',', '', $unit_cost_usd);

                                        $profit = profit_percent($state, $unit_cost_usd);

                                        if($profit > 0)
                                        {
                                            $set('profit', number_format($profit, 2));
                                        }else{
                                            $set('profit', "-");
                                        }
                                    }
                                }
                            }),

                        Forms\Components\TextInput::make('profit')
                            ->dehydrated(false)
                            ->reactive()
                            ->maxValue(10000)
                            ->suffix('%')
                            ->disabled(function (Forms\Get $get){
                                return $get('last_stock_unit_cost_sdg') == null or $get('last_stock_unit_cost_sdg') == "-";
                            })
                            ->afterStateUpdated(function (Forms\Set $set, $state, Forms\Get $get){
                                $unit_cost_sdg = $get('last_stock_unit_cost_sdg');

                                if($unit_cost_sdg){
                                    try {
                                        $unit_cost_sdg = \Str::replace(',' , '', $unit_cost_sdg);
                                        $sdg_price_calculated_from_percent = $state / 100 * $unit_cost_sdg + ($unit_cost_sdg);
                                        $set('sdg_price', number_format($sdg_price_calculated_from_percent, 0, '', ''));

                                        $ex_rate = $get('exchange_rate');

                                        if($ex_rate)
                                            $set('usd_price', number_format($sdg_price_calculated_from_percent / $ex_rate, 2, '.', ''));
                                    }catch (\Exception $exception){}
                                }
                            })
                            ->label(__('fields.profit_percent')),

                        Forms\Components\Hidden::make('date')->default(now())
                    ])->columns(3)
                ]);
        }

        public static function table(Tables\Table $table): Tables\Table
        {
            return $table
                ->columns([
                    Tables\Columns\TextColumn::make('acc4.item.barcode')
                        ->searchable(query: function (Builder $query, string $search): Builder {
                            return $query->whereHas('acc4', function (Builder $q2) use ($search) {
                                return $q2->whereHasMorph('item', [Product::class], function (Builder $q3) use ($search) {
                                    return $q3->where('barcode', 'like', "%{$search}%");
                                });
                            });
                        })
                        ->label(__('fields.barcode')),

                    Tables\Columns\TextColumn::make('acc4.item.name')
                        ->searchable()
                        ->label(__('fields.name')),

                    Tables\Columns\TextColumn::make('sdg_price')
                        ->searchable()
                        ->tooltip(function ($record) {
                            return tafqeet($record->sdg_price, 'egp');
                        })
                        ->getStateUsing(function ($record) {
                            return number_format($record->sdg_price, 2) . ' SDG';
                        })
                        ->label(__('fields.price_sdg')),

                    Tables\Columns\TextColumn::make('usd_price')
                        ->searchable()
                        ->tooltip(function ($record) {
                            return tafqeet($record->usd_price, 'usd');
                        })
                        ->getStateUsing(function ($record) {
                            return number_format($record->usd_price, 2) . ' USD';
                        })
                        ->label(__('fields.price_usd')),

                    Tables\Columns\TextColumn::make('exchange_rate')
                        ->searchable()
                        ->label(__('fields.exchange_rate')),

                    Tables\Columns\TextColumn::make('profit')
                        ->label(__('fields.profit_percent'))
                        ->extraAttributes(function ($record){
                            if ($record->acc4->item->lastStock)
                                return ['class' => 'text-success-700'];

                            return ['class' => 'text-danger-700'];
                        })
                        ->getStateUsing(function ($record) {
                            if ($record->acc4->item->lastStock)
                                return number_format(profit_percent($record->sdg_price, $record->acc4->item->lastStock->unit_cost_sdg), 2) . "%";

                            return "No stock available to calculate";
                        }),

                    Tables\Columns\TextColumn::make('date')
                        ->label(__('fields.date'))
                        ->dateTime('M j, Y h:i a')
                        ->sortable(),

                ])
                ->filters([

                    Tables\Filters\Filter::make('product_id')
                        ->label(__('fields.product'))
                        ->form([
                            Forms\Components\Select::make('product_id')
                                ->label(__('fields.product'))
                                ->searchable()
                                ->options(Product::has('lastPrice')->pluck('name', 'id')),
                        ])
                        ->query(function (Builder $query, array $data): Builder {
                            return $query
                                ->when(
                                    $data['product_id'],
                                    function (Builder $query, $product_id) {
                                        return $query->whereHas('acc4', function (Builder $q2) use ($product_id) {
                                            return $q2->whereHasMorph('item', [Product::class], function (Builder $q3) use ($product_id) {
                                                return $q3->where('id', $product_id);
                                            });
                                        });
                                    },
                                );
                        }),

                    Tables\Filters\Filter::make('created_at')
                        ->form([
                            Forms\Components\DatePicker::make('created_from')
                                ->label(__('fields.created_from')),
                            Forms\Components\DatePicker::make('created_until')
                                ->label(__('fields.created_until')),
                        ])
                        ->query(function (Builder $query, array $data): Builder {
                            return $query
                                ->when(
                                    $data['created_from'],
                                    fn(Builder $query, $date): Builder => $query->whereDate('created_at', '>=', $date),
                                )
                                ->when(
                                    $data['created_until'],
                                    fn(Builder $query, $date): Builder => $query->whereDate('created_at', '<=', $date),
                                );
                        })

                ])
                ->actions([
                    Tables\Actions\ActionGroup::make([
                        Tables\Actions\ViewAction::make(),
                        Tables\Actions\EditAction::make()->using(function (array $data, $record) {
                            unset($data['profit']);
                            $record->update($data);
                        }),
                        Tables\Actions\DeleteAction::make(),
                    ]),
                ])
                ->bulkActions([

                ])->deferLoading();
        }

        public static function getEloquentQuery(): Builder
        {
            return parent::getEloquentQuery()->with(['acc4.item.lastPrice', 'acc4.item.lastStock'])->latest();
        }


        public static function getPages(): array
        {
            return [
                'index' => Pages\ManageItemPricings::route('/'),
            ];
        }

        public static function getWidgets(): array
        {
            return [
                MissingPricingOverview::class
            ];
        }
    }
