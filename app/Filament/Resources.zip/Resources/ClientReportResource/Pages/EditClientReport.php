<?php

namespace App\Filament\Resources\ClientReportResource\Pages;

use App\Filament\Resources\ClientReportResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\EditRecord;

class EditClientReport extends EditRecord
{
    protected static string $resource = ClientReportResource::class;

    protected function getActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
