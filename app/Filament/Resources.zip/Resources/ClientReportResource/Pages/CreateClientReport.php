<?php

namespace App\Filament\Resources\ClientReportResource\Pages;

use App\Filament\Resources\ClientReportResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateClientReport extends CreateRecord
{
    protected static string $resource = ClientReportResource::class;
}
