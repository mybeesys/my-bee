<?php

    namespace App\Filament\Resources;

    use App\Filament\Resources\ReceiptVoucherResource\Pages;
    use App\Filament\Resources\ReceiptVoucherResource\RelationManagers;
    use App\Models\Acc4;
    use App\Models\Client;
    use App\Models\Currency;
    use App\Models\Invoice;
    use App\Models\ReceiptVoucher;
    use Filament\Facades\Filament;
    use Filament\Forms;
    use Filament\Forms\Components\Card;
    use Filament\Forms\Components\DatePicker;
    use Filament\Forms\Components\Group;
    use Filament\Forms\Components\Repeater;
    use Filament\Forms\Components\Select;
    use Filament\Forms\Components\TextInput;
    use Filament\Resources\Form;
    use Filament\Resources\Resource;
    use Filament\Resources\Table;
    use Filament\Tables;
    use Illuminate\Database\Eloquent\Builder;
    use Illuminate\Database\Eloquent\SoftDeletingScope;

    class ReceiptVoucherResource extends Resource
    {
        protected static ?string $model = ReceiptVoucher::class;

        protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

        protected static ?string $recordTitleAttribute = "no";

        protected static ?string $slug = "finance/receipt-vouchers";

        protected static ?int $navigationSort = 1;

        public static function getNavigationGroup(): ?string
        {
            return __('fields.finance');
        }

        public static function getLabel(): ?string
        {
            return __('fields.receipt_voucher');
        }

        public static function getPluralLabel(): ?string
        {
            return __('fields.receipt_vouchers');
        }

        public static function shouldRegisterNavigation(): bool
        {
            return false;
            return module_enabled('finance');
        }

        public static function getNavigationBadge(): ?string
        {
            return static::getModel()::count();
        }

        public static function form(Forms\Form $form): Forms\Form
        {
            return $form
                ->schema(static::getFormSchema(Forms\Components\Card::class))
                ->columns([
                    'sm' => 3,
                    'lg' => null,
                ]);
        }

        public static function getFormSchema(string $layout = Forms\Components\Grid::class): array
        {
            return [
                Forms\Components\Group::make()
                    ->schema([


                    ])->columnSpan([
                        'sm' => 3,
                    ]),
            ];
        }


        public static function table(Tables\Table $table): Tables\Table
        {
            return $table
                ->columns([
                    Tables\Columns\TextColumn::make('no')
                        ->label(__('fields.invoice_no')),

                    Tables\Columns\TextColumn::make('date')
                        ->label(__('fields.date'))
                        ->dateTime('M j, Y')
                        ->searchable(),

                    Tables\Columns\TextColumn::make('invoice.no')
                        ->label(__('fields.invoice_no')),

                    Tables\Columns\TextColumn::make('invoice.client.name')
                        ->label(__('fields.client'))
                        ->searchable(),

                    Tables\Columns\TextColumn::make('paid_amount')
                        ->label(__('fields.paid_amount'))
                        ->getStateUsing(function ($record) {
                            return number_format($record->invoice->total_paid['sdg'], 2) . ' SDG';
                        }),

                    Tables\Columns\TextColumn::make('paid_amount_percent')
                        ->extraAttributes(function ($record) {
                            if (percent($record->invoice->total_paid['sdg'], $record->invoice->getItemsCost('SDG')) > 0) {
                                return ['class' => 'text-success-700'];
                            }

                            return ['class' => 'text-danger-700'];
                        })
                        ->label(__('fields.paid_amount_percent'))
                        ->getStateUsing(function ($record) {
                            return number_format(percent($record->invoice->total_paid['sdg'], $record->invoice->getItemsCost('SDG')), 2) . '%';
                        }),

                    Tables\Columns\TextColumn::make('invoice_total_sdg')
                        ->label(__('fields.invoice_total_sdg'))
                        ->getStateUsing(function ($record) {
                            return number_format($record->invoice->getItemsCost("SDG"), 2) . ' SDG';
                        }),

                    Tables\Columns\TextColumn::make('invoice_total_usd')
                        ->label(__('fields.invoice_total_usd'))
                        ->getStateUsing(function ($record) {
                            return number_format($record->invoice->getItemsCost("USD"), 2) . ' USD';
                        }),
                ])
                ->filters([
                    //
                ])
                ->actions([
                    Tables\Actions\ActionGroup::make([
                        Tables\Actions\EditAction::make(),
                    ])
                ])
                ->bulkActions([
                ]);
        }

        public static function getRelations(): array
        {
            return [
                //
            ];
        }

        public static function getEloquentQuery(): Builder
        {
            return parent::getEloquentQuery()->with(['invoice.client', 'user'])->latest();
        }

        public static function getPages(): array
        {
            return [
                'index' => Pages\ListReceiptVouchers::route('/'),
                'create' => Pages\CreateCustomReceiptVoucher::route('/create'),
                'edit' => Pages\EditCustomReceiptVoucher::route('/{record}/edit'),
            ];
        }
    }
